/* 
 * File:   GardenPlan.h
 * Author: Lukas Elmer
 *
 * Created on 3. Mai 2010, 19:43
 */

#ifndef _GARDENPLAN_H
#define	_GARDENPLAN_H

#include "ShapePtr.h"
#include <vector>

typedef std::vector<ShapePtr> GardenPlan;

#endif	/* _GARDENPLAN_H */

