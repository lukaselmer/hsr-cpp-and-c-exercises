/* 
 * File:   Square.cpp
 * Author: Lukas Elmer
 * 
 * Created on 3. Mai 2010, 19:44
 */

#include "Square.h"

Square::~Square() {
}
