#ifndef HAUSTIER_H_
#define HAUSTIER_H_
#include <string>
#include <boost/shared_ptr.hpp>
#include <iosfwd>
class Haustier {
protected:
	const std::string name;
	const std::string klassenname;
public:
	Haustier(std::string name,std::string klasse);
	virtual ~Haustier();
	virtual void gibLaut() const;
	void printName() const;
	virtual void printEigenschaft(std::ostream &os) const;
    std::string getName() const { return name + " : ein " + klassenname + " ";}

};
typedef boost::shared_ptr<Haustier> TierPtr;
#endif /* HAUSTIER_H_ */
