#include "Wort.h"
#include <iostream>
#include <iterator>
#include <set>
int main(){
	using namespace std;
	istream_iterator<Wort> eof;
	set<Wort> alle(istream_iterator<Wort>(cin),eof);
	cout << alle.size()<<endl;
}
