#ifndef Wort_H_
#define Wort_H_
#include <string>
#include <iosfwd>
class Wort {
	std::string	wort;
public:
	Wort(std::string s=""):wort(s){}
	bool operator<(Wort const & rhs)const;
	void readFrom(std::istream&);
};
std::istream& operator>>(std::istream&,Wort&);
#endif
