#include "Wort.h"
#include <iostream>
#include <iterator>
#include <map>

void print(std::pair<Wort,int> const &p){
	std::cout << p.first << ":\t" << p.second << std::endl;
}
int main(){
	using namespace std;
	istream_iterator<Wort> eof;
	map<Wort,int> alle;
	for(istream_iterator<Wort> i(cin); i!=eof; ++i)
		++alle[*i];
	for_each(alle.begin(),alle.end(),print);
}
