#include <iostream>
int main() {
    std::cout << "Hello, world\n";
}

struct Tracer {
	Tracer() {
		std::cout << "Initialisierung" << std::endl;
	}
	~Tracer(){
		std::cout << "Aufraeumen" << std::endl;
	}
};

Tracer t;
