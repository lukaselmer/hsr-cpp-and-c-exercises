#include <iostream>
#include <iterator>
#include <vector>

bool isPrime(int n){
	if (n<=1) return false;
	for (int i = 2; i * i <= n; ++i){
		if (0 == n%i) return false;
	}
	return true;
}
bool isNotPrime(int n){
	return not isPrime(n);
}

int iGenerate(){
	static int i = 1;
	return i++;
}

int main(){
	using namespace std;
	vector<int> v;
	for (int i=1; i <=100; ++i) v.push_back(i);
//	generate_n(back_inserter(v),100,iGenerate);
//	remove_copy_if(v.begin(),v.end(),ostream_iterator<int>(cout,", "),not1(ptr_fun(isPrime)));
	remove_copy_if(v.begin(),v.end(),ostream_iterator<int>(cout,", "),isNotPrime);

	cout << endl<< count_if(v.begin(),v.end(),isPrime) << " primes" << endl;
}

