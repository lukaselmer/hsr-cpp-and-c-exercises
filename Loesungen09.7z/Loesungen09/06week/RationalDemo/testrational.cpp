#include "Rational.h"
#include <iostream>
using namespace std;
int main(){
	Rational r1(3,4);
	Rational r2(3,9);
	cout << r1<< " + " << r2 << " = " << r1 + r2 << endl;
	cout << "2 + 1/2 = "<< 2 + Rational(1,2) << endl;
}
