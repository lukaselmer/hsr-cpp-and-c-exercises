#endif /* WORT_H_ */
#ifndef Wort_H_
#define Wort_H_
#include <string>
#include <iosfwd>
class Wort {
	std::string wort;
public:
	explicit Wort(std::string s = "") :
		wort(s) {
	}
	void readFrom(std::istream&);
};
std::istream& operator>>(std::istream&, Wort&);
#endif
