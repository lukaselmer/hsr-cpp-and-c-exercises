#include "Wort.h"
#include <iostream>
#include <iterator>
int main(){
	using namespace std;
	istream_iterator<Wort> eof;
	cout<< distance(istream_iterator<Wort>(cin),eof)<<endl; 
}
