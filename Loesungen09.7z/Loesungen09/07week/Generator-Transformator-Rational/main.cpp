#include "Rational.h"
#include <iostream>
#include <iterator>
#include <vector>
#include <algorithm>
#include <functional>
#include <boost/bind.hpp>

struct reciprocal {
	reciprocal(int j):i(j){}
	Rational operator()(){
		return Rational(1,i++);
	}
	int i;
};

void print(std::vector<Rational> v){
	using namespace std;
	copy(v.begin(),v.end(),ostream_iterator<Rational>(cout,", "));
	cout << endl;
}
int main() {
	using namespace std;
	vector<Rational> v,v2;
	generate_n(back_inserter(v),20,reciprocal(1));
	print(v);
	transform(v.begin(),v.end(),back_inserter(v2),boost::bind(multiplies<Rational>(),_1,_1));
	print(v2);
	transform(v.begin(),v.end(),v2.begin(),ostream_iterator<Rational>(cout,", "),multiplies<Rational>());
}
