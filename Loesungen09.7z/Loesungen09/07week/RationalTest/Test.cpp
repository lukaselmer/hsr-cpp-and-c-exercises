#include "cute.h"
#include "ide_listener.h"
#include "cute_runner.h"
#include "Rational.h"
#include <boost/lexical_cast.hpp>
#include <limits>
//-- week 7 tests for type conversion operators
void testOperatorDouble(){
	Rational r(1,2);
	ASSERT_EQUAL(0.5,static_cast<double>(r));
}

void testOperatorFloat(){
	Rational r(1,4);
	ASSERT_EQUAL(0.25f,static_cast<float>(r));
}

void testOperatorInt(){
	Rational r(8,3);
	ASSERT_EQUAL(2,static_cast<int>(r));
}
void testFromExercise(){
	Rational r1(7,3);
	double d = (double)r1 + 2.0; // overload conflict with int 2
	int i = static_cast<int>(r1) + 0.7; // requires static_cast<double>
	ASSERT_EQUAL(static_cast<double>(Rational(13,3)),d);
	ASSERT_EQUAL(2,i);
}



//-- woche 6 demo tests
void testAdd(){
	Rational half(1,2);
	Rational one(1,1);
	ASSERT_EQUAL(one,half+half);
}
void testAddWithNormalize(){
	Rational  half(1,2);
	Rational twothirds(2,3);
	Rational sevensixth(7,6);
	ASSERT_EQUAL(sevensixth,half+twothirds);
}

void testIsLower(){
	Rational one(1,1);
	Rational lessthanOne = one - Rational(1,std::numeric_limits<long>::max());
	ASSERT(lessthanOne < one);
	ASSERT(!(one < lessthanOne));
}

void testExceptionWhenZero(){
	ASSERT_THROWS(Rational(1,0),Rational::bad_rational);
}
void testInputThrows(){
	std::string input("1/x");
	std::istringstream is(input);
	Rational number;
	ASSERT_THROWS(is >> number, Rational::bad_rational);
	ASSERT(!is);
}




void runSuite(){
	cute::suite s;
	//TODO add your test here
	s.push_back(CUTE(testAdd));
	s.push_back(CUTE(testAddWithNormalize));
	s.push_back(CUTE(testIsLower));
	s.push_back(CUTE(testExceptionWhenZero));
	s.push_back(CUTE(testInputThrows));
	s.push_back(CUTE(testOperatorDouble));
	s.push_back(CUTE(testOperatorFloat));
	s.push_back(CUTE(testOperatorInt));
	s.push_back(CUTE(testFromExercise));
	cute::ide_listener lis;
	cute::makeRunner(lis)(s, "The Suite");
}

int main(){
    runSuite();
}



