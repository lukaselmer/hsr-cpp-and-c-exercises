#include <iostream>
#include <iterator>
#include <vector>
#include <algorithm>
#include <functional>
#include <boost/bind.hpp>

struct reciprocal {
	reciprocal(int j):i(j){}
	double operator()(){
		return 1.0/i++;
	}
	int i;
};

void print(std::vector<double> v){
	using namespace std;
	copy(v.begin(),v.end(),ostream_iterator<double>(cout,", "));
	cout << endl;
}
int main() {
	using namespace std;
	vector<double> v,v2;
	generate_n(back_inserter(v),20,reciprocal(1));
	print(v);
	transform(v.begin(),v.end(),back_inserter(v2),boost::bind(multiplies<double>(),_1,_1));
	print(v2);
	transform(v.begin(),v.end(),v2.begin(),ostream_iterator<double>(cout,", "),multiplies<double>());
}
