#include <iostream>
#include <iterator>
#include <string>
#include <algorithm>
#include <boost/bind.hpp>
bool isNotPalindrome(std::string s){
	std::transform(s.begin(),s.end(),s.begin(),::tolower);
	return ! std::equal(s.begin(),s.end(),s.rbegin());
}
int main(){
	using namespace std;
	using namespace boost;
	remove_copy_if(istream_iterator<string>(cin),istream_iterator<string>(),
			  ostream_iterator<string>(cout,"\n"),isNotPalindrome);
}

//bind<bool>(&std::equal<string::iterator,string::reverse_iterator>,
//		  bind<string::iterator>(&string::begin,_1),
//		  bind<string::iterator>(&string::end,_1),
//		  bind<string::reverse_iterator>(&string::rbegin,_1)));
