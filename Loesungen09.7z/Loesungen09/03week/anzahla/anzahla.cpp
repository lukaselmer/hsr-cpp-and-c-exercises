#include <iostream>
#include <iterator>
#include <algorithm>

int main(){
	using namespace std;
	istream_iterator<char> eof;
	cout << count(istream_iterator<char>(cin),eof,'a')<<endl;
}
