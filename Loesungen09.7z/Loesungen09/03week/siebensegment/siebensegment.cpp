#include "siebensegment.h"
#include <iostream>
#include <vector>
#include <boost/assign.hpp>
void printLargeDigit(int i, std::ostream & out)
{
	for (int j=0; j < 5; ++j)
		out << getDigitLine(i,j)<< std::endl;
}

namespace {
	std::vector<std::vector<std::string> > digitLines(10);
	bool initialized=false;
	void initializeDigitLines(){
		using namespace boost::assign;
		using namespace std;
		digitLines[0] += " - ","| |","   ","| |"," - ";
		digitLines[1] += "   ","  |","   ","  |","   ";
		digitLines[2] += " - ","  |"," - ","|  "," - ";
		digitLines[3] += " - ","  |"," - ","  |"," - ";
		digitLines[4] += "   ","| |"," - ","  |","   ";
		digitLines[5] += " - ","|  "," - ","  |"," - ";
		digitLines[6] += " - ","|  "," - ","| |"," - ";
		digitLines[7] += " - ","  |","   ","  |","   ";
		digitLines[8] += " - ","| |"," - ","| |"," - ";
		digitLines[9] += " - ","| |"," - ","  |"," - ";
		initialized=true;
	}
}


std::string getDigitLine(int i, int line)
{
	if (!initialized)initializeDigitLines();
	return digitLines[i][line];
}

