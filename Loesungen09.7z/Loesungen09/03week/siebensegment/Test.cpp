#include "cute.h"
#include "ide_listener.h"
#include "cute_runner.h"
#include "siebensegment.h"
void testZeroLine0() {
	ASSERT_EQUAL(" - ",getDigitLine(0,0));
}
void testZeroLine1() {
	ASSERT_EQUAL("| |",getDigitLine(0,1));
}
void testZeroLine2() {
	ASSERT_EQUAL("   ", getDigitLine(0,2));
}
void testZeroLine3() {
	ASSERT_EQUAL("| |",getDigitLine(0,3));
}

void testZeroLine4() {
	ASSERT_EQUAL(" - ",getDigitLine(0,4));
}
void testOneWithStream(){
	std::ostringstream os;
	printLargeDigit(1,os);
	ASSERT_EQUAL("   \n  |\n   \n  |\n   \n",os.str());
}
void testTwoWithStream(){
	std::ostringstream os;
	printLargeDigit(2,os);
	ASSERT_EQUAL(" - \n  |\n - \n|  \n - \n",os.str());
}
void testThreeWithStream(){
	std::ostringstream os;
	printLargeDigit(3,os);
	ASSERT_EQUAL(" - \n  |\n - \n  |\n - \n",os.str());
}
void testFourWithStream(){
	std::ostringstream os;
	printLargeDigit(4,os);
	ASSERT_EQUAL("   \n| |\n - \n  |\n   \n",os.str());
}

void testFiveWithStream(){
	std::ostringstream os;
	printLargeDigit(5,os);
	ASSERT_EQUAL(" - \n|  \n - \n  |\n - \n",os.str());
}

void testSixWithStream(){
	std::ostringstream os;
	printLargeDigit(6,os);
	ASSERT_EQUAL(" - \n|  \n - \n| |\n - \n",os.str());
}
void testSevenWithStream(){
	std::ostringstream os;
	printLargeDigit(7,os);
	ASSERT_EQUAL(" - \n  |\n   \n  |\n   \n",os.str());
}
void testEightWithStream(){
	std::ostringstream os;
	printLargeDigit(8,os);
	ASSERT_EQUAL(" - \n| |\n - \n| |\n - \n",os.str());
}
void testNineWithStream(){
	std::ostringstream os;
	printLargeDigit(9,os);
	ASSERT_EQUAL(" - \n| |\n - \n  |\n - \n",os.str());
}
void testZeroWithStream(){
	std::ostringstream os;
	printLargeDigit(0,os);
	ASSERT_EQUAL(" - \n| |\n   \n| |\n - \n",os.str());
}
void runSuite() {
	cute::suite s;
	//TODO add your test here
	s.push_back(CUTE(testZeroLine0));
	s.push_back(CUTE(testZeroLine1));
	s.push_back(CUTE(testZeroLine2));
	s.push_back(CUTE(testZeroLine3));
	s.push_back(CUTE(testZeroLine4));
	s.push_back(CUTE(testOneWithStream));
	s.push_back(CUTE(testTwoWithStream));
	s.push_back(CUTE(testThreeWithStream));
	s.push_back(CUTE(testFourWithStream));
	s.push_back(CUTE(testFiveWithStream));
	s.push_back(CUTE(testSixWithStream));
	s.push_back(CUTE(testSevenWithStream));
	s.push_back(CUTE(testEightWithStream));
	s.push_back(CUTE(testNineWithStream));
	s.push_back(CUTE(testZeroWithStream));
	cute::ide_listener lis;
	cute::makeRunner(lis)(s, "The Suite");
}

int main() {
	runSuite();
}

