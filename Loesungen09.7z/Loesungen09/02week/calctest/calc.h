#ifndef CALC_H_
#define CALC_H_
int calc(int,int,char);
#endif /* CALC_H_ */
