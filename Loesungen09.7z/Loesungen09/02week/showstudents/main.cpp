#include <iostream>
#include <fstream>
#include <string>

#include "Studentenliste.h"

using namespace std;

const char* FILENAME = "./students09.txt"; // ev. anpassen

int main() {
    // F�r Test mit Input aus Datei, diese Zeile kommentieren
    showStudents(cin);

    // Test mit Input von Konsole die folgenden Zeilen kommentieren
    ifstream in(FILENAME);
    if (in)
        showStudents(in);
    else
        cout << "Problems opening " << FILENAME << endl;
}
