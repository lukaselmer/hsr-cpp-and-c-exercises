#ifndef STUDENTENLISTE_H_
#define STUDENTENLISTE_H_
#include <iosfwd>
void showStudents(std::istream &in);
#endif /* STUDENTENLISTE_H_ */
