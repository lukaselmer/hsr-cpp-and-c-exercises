#include <iostream>
#include <iterator>

int main(){
	char c;
	int count=0;
	while (std::cin >> c) {
		++count;
	}
	std::cout << count << std::endl;

	//std::cout << distance(std::istream_iterator<char>(std::cin),std::istream_iterator<char>())<< std::endl;
}
