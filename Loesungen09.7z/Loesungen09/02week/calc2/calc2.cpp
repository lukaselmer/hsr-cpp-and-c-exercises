#include "calc2.h"
#include <iostream>

int calc(std::istream & in)
{
	int x,y;
	char oper;
	in >> x >> oper >> y;
	return calc(x,y,oper);
}

int calc(int x, int y, char oper)
{
	switch(oper){
	case '+': return x+y;
	case '-': return x-y;
	case '*': return x*y;
	case '/': return y!=0?x/y:0; // avoid crashes
	}
	return x+y;
}



