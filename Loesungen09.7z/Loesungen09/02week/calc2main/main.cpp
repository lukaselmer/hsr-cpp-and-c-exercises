#include "calc2.h"
#include <iostream>

int main() {
	while (std::cin)
	std::cout << calc(std::cin) << std::endl;
}
