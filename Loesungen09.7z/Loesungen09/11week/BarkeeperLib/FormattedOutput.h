/*
 * FormattedOutput.h
 *
 *  Created on: May 14, 2009
 *      Author: m1huber
 */

#ifndef FORMATTEDOUTPUT_H_
#define FORMATTEDOUTPUT_H_

#include "InputReader.h"
#include <iostream>
#include <iomanip>
#include <algorithm>
#include <boost/bind.hpp>

struct printBeverages {
	typedef InputReader::mapType T;
	typedef InputReader::mapPairType PT;
	std::ostream& stream;
	T const& theMap;
	char cFill;
	int iWidth;
	printBeverages(std::ostream& os, T const& aMap, char aFill, int iW) :
		stream(os), theMap(aMap), cFill(aFill), iWidth(iW) {
	}
	~printBeverages();
	void printNum(int iCount) {
		stream << std::setfill(cFill) << std::setw(3);
		if (iCount == 0) {
			stream << cFill;
		} else {
			stream << iCount;
		}
	}
	void printBev(int iCount, PT const & aPair) {
		stream << std::setfill(cFill) << std::setw(iWidth);
		if (iCount == 0) {
			stream << aPair.first;
		} else {
			stream << std::fixed << std::setprecision(2) << (iCount
					* aPair.second);
		}
	}
	void operator()(int iCount) {
		if (theMap.size()) {
			printNum(iCount);
			std::for_each(theMap.begin(), theMap.end(), boost::bind(
					&printBeverages::printBev, this, iCount, _1));
			stream << std::endl;
		}
	}
};

#endif /* FORMATTEDOUTPUT_H_ */
