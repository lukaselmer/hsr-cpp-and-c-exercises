/*
 * FromattedOutput.cpp
 *
 *  Created on: May 14, 2009
 *      Author: m1huber
 */

#include "FormattedOutput.h"

printBeverages::~printBeverages() {
}
