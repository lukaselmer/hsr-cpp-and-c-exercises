#ifndef SiebenSegmentZiffer_H_
#define SiebenSegmentZiffer_H_

#include <string>
#include <vector>

class SiebenSegmentZiffer {
public:
	struct invalid_digit{};
	SiebenSegmentZiffer(int digit);
	SiebenSegmentZiffer(char letter);
	std::string getDigitLine(int line,unsigned int factor=1) const;
	static int const nOfLines=5;
private:
	std::vector<std::string> digitLines;

};

#endif /*SiebenSegmentZiffer_H_*/
