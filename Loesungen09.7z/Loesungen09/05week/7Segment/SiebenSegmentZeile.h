#ifndef SiebenSegmentZeile_H_
#define SiebenSegmentZeile_H_
#include <vector>
#include <iosfwd>
#include <string>
#include "SiebenSegmentZiffer.h"
class SiebenSegmentZeile {
public:
	SiebenSegmentZeile(int zahl);
	SiebenSegmentZeile(std::string s);
	void print(std::ostream &out,unsigned int factor=1) const;
	std::string getLine(int line, unsigned int factor=1)const;
private:
    bool lineNeedsRepetition(int line) const;
    void fillLeft();
	std::vector<SiebenSegmentZiffer> theDigits;
};
#endif /*SiebenSegmentZeile_H_*/
