#include "calc2.h"
#include <iostream>
#include <string>
#include <sstream>
#include <stdexcept>
#include "SiebenSegmentZeile.h"
#include "Ansi.h"

void screenHome()
{
    std::cout << Ansi::Clear() + Ansi::Home() + Ansi::ForeColor(Ansi::green) + Ansi::BackColor(Ansi::black)+Ansi::Bold()<< std::flush;
}
void resetBlackWhite()
{
    std::cout << Ansi::AttrOff()+Ansi::BackColor(Ansi::white) + Ansi::ForeColor(Ansi::black)<<std::flush;
}
void resetRedWhite()
{
    std::cout << Ansi::AttrOff()+Ansi::BackColor(Ansi::white) + Ansi::ForeColor(Ansi::red)<<std::flush;
}



int main(){
	std::string line;
	screenHome();
    resetBlackWhite();
    while(getline(std::cin, line)){
        std::istringstream is(line);
        try {
        	screenHome();
        	SiebenSegmentZeile output(calc(is));
            output.print(std::cout);
            resetBlackWhite();
            std::cout << line << Ansi::Left(line.size()) << std::flush;
        }catch(std::exception &e){
			SiebenSegmentZeile("Error").print(std::cout);
            resetRedWhite();
			std::cout << "Error:" << e.what() << " at " << line << std::endl;
		}catch (...) {
			SiebenSegmentZeile("Error").print(std::cout);
            resetRedWhite();
			std::cout << "unkown Error at " << line << std::endl;
		}
        resetBlackWhite();
	}
}
