#include "calc2.h"
#include <iostream>
#include <string>
#include <sstream>
#include <stdexcept>
#include "SiebenSegmentZeile.h"
int main(){
	std::string line;
	while(getline(std::cin,line)){
		std::istringstream is(line);
		try {
			SiebenSegmentZeile output(calc(is));
			output.print(std::cout);
			//std::cout << "= " << calc(is) << std::endl;//variante ohne 7segment
		}catch(std::exception &e){
			SiebenSegmentZeile("Error").print(std::cout);
			std::cerr << "Error:" << e.what() << " at " << line << std::endl;
		}catch (...) {
			SiebenSegmentZeile("Error").print(std::cout);
			std::cerr << "unkown Error at " << line << std::endl;
		}
	}
}
