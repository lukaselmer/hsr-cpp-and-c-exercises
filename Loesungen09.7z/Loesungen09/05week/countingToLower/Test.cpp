#include "cute.h"
#include "ide_listener.h"
#include "cute_runner.h"

#include <cctype>

int countingToLower(std::string &s){
	int wasUpper=0;
	for (size_t i=0; i < s.size(); ++i)
		if (isupper(s[i])) {
			++wasUpper;
			s[i] = tolower(s[i]);
		}
	return wasUpper;
}
// kein gutes Design, Seiteneffekt und R�ckgabe von Information.

void lowerFirstCharacter() {
	std::string str("Hello!");
	ASSERT_EQUAL(1, countingToLower(str));
	ASSERT_EQUAL("hello!", str);
}

void lowerSeveralCharacters() {
	std::string str("Hello World, its ME!");
	ASSERT_EQUAL(4, countingToLower(str));
	ASSERT_EQUAL("hello world, its me!", str);
}

void lowerNone() {
	std::string str("no uppercase characters here");
	ASSERT_EQUAL(0, countingToLower(str));
	ASSERT_EQUAL("no uppercase characters here", str);
}

void lowerAll() {
	std::string str("LOL");
	ASSERT_EQUAL(3, countingToLower(str));
	ASSERT_EQUAL("lol", str);
}

void lowerEmpty() {
	std::string str("");
	ASSERT_EQUAL(0, countingToLower(str));
	ASSERT_EQUAL("", str);
}

void umlautsAreNotChanged() {
	std::string str("���");
	ASSERT_EQUAL(0, countingToLower(str));
	ASSERT_EQUAL("���", str);
}

void runSuite(){
	cute::suite s;
	//TODO add your test here
	s.push_back(CUTE(lowerFirstCharacter));
	s.push_back(CUTE(lowerSeveralCharacters));
	s.push_back(CUTE(lowerNone));
	s.push_back(CUTE(lowerAll));
	s.push_back(CUTE(lowerEmpty));
	s.push_back(CUTE(umlautsAreNotChanged));
	cute::ide_listener lis;
	cute::makeRunner(lis)(s, "The Suite");
}

int main(){
    runSuite();
}



