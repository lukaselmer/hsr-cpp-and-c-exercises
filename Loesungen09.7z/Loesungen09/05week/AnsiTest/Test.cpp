#include "cute.h"
#include "ide_listener.h"
#include "cute_runner.h"
#include "Ansi.h"
void testClear(){
	ASSERT_EQUAL("\033[2J",Ansi::Clear());
}
void testForeColorWhite() {
	ASSERT_EQUAL("\033[37m",Ansi::ForeColor(Ansi::white));
}
void testBAckColorBlack(){
	ASSERT_EQUAL("\033[40m",Ansi::BackColor(Ansi::black));
}
void testBold(){
	ASSERT_EQUAL("\033[1m",Ansi::Bold());
}
void testAttrOff(){
	ASSERT_EQUAL("\033[0m",Ansi::AttrOff());
}
void testPosXY(){
	ASSERT_EQUAL("\033[2;3H",Ansi::Pos(2,3));
}
void testHome(){
	ASSERT_EQUAL("\033[0;0H",Ansi::Home());
}
void testUp(){
	ASSERT_EQUAL("\033[2A",Ansi::Up(2));
}
void testDown(){
	ASSERT_EQUAL("\033[3B",Ansi::Down(3));
}
void testRight(){
	ASSERT_EQUAL("\033[4C",Ansi::Right(4));
}
void testLeft(){
	ASSERT_EQUAL("\033[5D",Ansi::Left(5));
}


void thisIsATest() {
	ASSERTM("start writing tests", false);
}

void runSuite(){
	cute::suite s;
	s.push_back(CUTE(testForeColorWhite));
	s.push_back(CUTE(testClear));

	s.push_back(CUTE(testBAckColorBlack));
	s.push_back(CUTE(testBold));
	s.push_back(CUTE(testAttrOff));
	s.push_back(CUTE(testPosXY));
	s.push_back(CUTE(testHome));
	s.push_back(CUTE(testUp));
	s.push_back(CUTE(testDown));
	s.push_back(CUTE(testLeft));
	s.push_back(CUTE(testRight));
	cute::ide_listener lis;
	cute::makeRunner(lis)(s, "The Suite");
}

int main(){
    runSuite();
}



