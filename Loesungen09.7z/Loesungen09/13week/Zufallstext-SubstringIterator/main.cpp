#include <iostream>
#include <iterator>
#include <string>
#include <set>
#include <map>
#include <algorithm>
#include <ext/algorithm> // for random_select
#include <boost/operators.hpp>

template <unsigned int n>
class substring_iterator:
public std::iterator<std::forward_iterator_tag,std::string>
, boost::equality_comparable<substring_iterator<n> >
, boost::incrementable<substring_iterator<n> >
{
	value_type s;
	typedef typename value_type::size_type size_type;
	size_type pos;
public:
	substring_iterator(std::string const &source=std::string()):s(source),pos(0){}
	value_type operator*()const{ return s.substr(pos,n); }
	bool operator==(substring_iterator const &other)const{
		if (other.s == s && other.pos == pos) return true;
		if (other.s.empty() && pos >= s.size()-n) return true;
		return false;
	}
	substring_iterator& operator++() { ++pos; return *this;}
};

template <unsigned int length>
class Schnipsel{
	template <int size>
	struct cmpFixedSize {
		bool operator()(std::string s1, std::string s2){
			s1.resize(size,' ');
			s2.resize(size,' ');
			return s1 < s2;
		}
	};
	typedef std::multiset<std::string,cmpFixedSize<length-1> > schnipsel_type;
	schnipsel_type	schnipsel;
	typedef typename schnipsel_type::const_iterator schnipsiter;
	template <typename Iter>
	std::string randomSelect(Iter begin, Iter end){
		using namespace __gnu_cxx;
		std::string s; // for ramdom_sample
		random_sample_n(begin,end,&s,1);
		return s;
	}

public:

	Schnipsel(std::string const &text)
	{
		substring_iterator<length> eos;
		std::copy(substring_iterator<length>(text),
				eos,
				std::inserter(schnipsel,schnipsel.begin()));
	}
	std::string getFirstSchnipsel(){
		return randomSelect(schnipsel.begin(),schnipsel.end());
	}
	char getNextChar(std::string last){
		const int relevantLength=length-1;
		std::string theComparable=last.substr(last.size()-relevantLength,relevantLength);
		std::pair<schnipsiter,schnipsiter> range=
			schnipsel.equal_range(theComparable);
		if (std::distance(range.first,range.second))
			return randomSelect(range.first,range.second)[length-1];
		return ' ';//nothing found return blanks
	}
	void appendNextSchnipsel(std::string &text){
		text += getNextChar(text.substr(text.size()-length,length));
	}
	void dump(){
		std::copy(schnipsel.begin(),schnipsel.end(),
		std::ostream_iterator<typename schnipsel_type::value_type>(std::cout,"\n"));
	}
};
char nl_to_blank(char c){
	return (c == '\n')?' ':c;
}
int main(){
	srand(time(0)); // make it more random.
	using namespace std;
	string text;
	istreambuf_iterator<char> eof;
	istreambuf_iterator<char> in(cin);
	transform(in,eof,back_inserter(text),nl_to_blank);
	Schnipsel<3> schnipsel(text);
	schnipsel.dump();
	string first = schnipsel.getFirstSchnipsel();
	while(first.size()<200) schnipsel.appendNextSchnipsel(first);
	cout << "result:\n"<<first<<endl;
}

