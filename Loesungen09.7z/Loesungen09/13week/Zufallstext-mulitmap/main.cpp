#include <iostream>
#include <iterator>
#include <string>
#include <map>
#include <algorithm>
#include <ext/algorithm> // for random_select

class Schnipsel{
	unsigned int length;
	typedef std::multimap<std::string,char > schnipsel_type;
	schnipsel_type	schnipsel;
	typedef schnipsel_type::value_type value_type;
	typedef std::pair<std::string,char> variable_type;
	typedef schnipsel_type::const_iterator schnipsiter;
	void insertSchnipsel(std::string::const_iterator it){
		schnipsel.insert(std::make_pair(std::string(it,it+length-1),it[length-1]));
	}
	value_type randomSelect(schnipsiter begin, schnipsiter end) const {
		using namespace __gnu_cxx;
		// using value_type is not possible, because we need to assign to it
		// std::map<std::string,char>::value_type is std::pair<std::string const, char>
		variable_type s; // for ramdom_sample
		random_sample_n(begin,end,&s,1);
		return s;
	}
	std::string lastChars(std::string s) const {
		if (s.size()<length) return s;
		// return the last length-1 chars
		return s.substr(s.size()-length+1,length-1);
	}
public:

	Schnipsel(std::string const &text, unsigned int n)
	:length(n)
	{
		std::string::const_iterator it=text.begin();
		while (it != text.end()-length){
			insertSchnipsel(it);
			++it;
		}
	}
	std::string getFirstSchnipsel() const {
		variable_type pair=
			randomSelect(schnipsel.begin(),schnipsel.end());
		return pair.first+pair.second;
	}
	char getNextChar(std::string text) const {
		std::pair<schnipsiter,schnipsiter> range=
			schnipsel.equal_range(lastChars(text));
		if (std::distance(range.first,range.second))
			return randomSelect(range.first,range.second).second;
		return ' ';//nothing found return blanks
	}
	void appendNextSchnipsel(std::string &text)const{
		text += getNextChar(text);
	}
};
char nl_to_blank(char c){
	return (c == '\n')?' ':c;
}
int main(){
	srand(time(0)); // make it more random.
	using namespace std;
	string text;
	istreambuf_iterator<char> eof;
	istreambuf_iterator<char> in(cin);
	transform(in,eof,back_inserter(text),nl_to_blank);
	Schnipsel schnipsel(text,3);
	string first = schnipsel.getFirstSchnipsel();
	while(first.size()<200) schnipsel.appendNextSchnipsel(first);
	cout << "result:\n"<<first<<endl;
}

