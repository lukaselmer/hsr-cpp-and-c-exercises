#include "cute.h"
#include "ide_listener.h"
#include "cute_runner.h"
#include "mitte.h"
#include <algorithm>
#include <vector>
void testMitteDouble() {
	ASSERT_EQUAL_DELTA(7.0 ,mitte(7.0, 7.1, 6.9), 0.0001);
}
void testMitteIntRechterWert() {
	ASSERT_EQUAL(5, mitte(3,9,5));
}
void testMitteString(){
	ASSERT_EQUAL("sechs", mitte<std::string>("vier","f�nf","sechs"));
}
void testMitteCharPtr(){
	ASSERT_EQUAL("sechs", mitte("vier","f�nf","sechs"));
}



void testMitteAlleIntPermutationen() {
	std::vector<int> v;
	v.push_back(3);
	v.push_back(5);
	v.push_back(9);
	std::sort(v.begin(), v.end());
	int counter(0);
	do {
		ASSERT_EQUAL(5, mitte(v[0],v[1],v[2]));
		++counter;
	} while (std::next_permutation(v.begin(), v.end()));
	ASSERT_EQUAL(6,counter);
}
void runSuite() {
	cute::suite s;
	//TODO add your test here
	s.push_back(CUTE(testMitteDouble));
	s.push_back(CUTE(testMitteIntRechterWert));
	s.push_back(CUTE(testMitteAlleIntPermutationen));
	s.push_back(CUTE(testMitteString));
	s.push_back(CUTE(testMitteCharPtr));
	cute::ide_listener lis;
	cute::makeRunner(lis)(s, "The Suite");
}

int main() {
	runSuite();
}

