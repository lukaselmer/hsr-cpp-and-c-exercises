#include "cute.h"
#include "ide_listener.h"
#include "cute_runner.h"
#include "Vector.h"
#include <stdexcept>
void testEmptyVector() {
	Vector<int> v;
	ASSERT_EQUAL(0,v.size());
}
Vector<int> generateData() {
	Vector<int> v;
	v.push_back(42);
	v.push_back(0);
	v.push_back(1);
	v.push_back(99);
	v.push_back(1000);
	return v;
}
void testAdressingWithMinus(){
	Vector<int> v=generateData();
	ASSERT_EQUAL(v[0],v[-v.size()]);
	ASSERT_EQUAL(v[v.size()-1],v[-1]);
}
void testAdressingWithAt(){
	Vector<int> v=generateData();
	ASSERT_EQUAL(v[v.size()-1], v.at(-1));
	ASSERT_EQUAL(v[0],v.at(-v.size()));
}
void testAtThrows(){
	Vector<int> v=generateData();
	ASSERT_THROWS(v.at(-(1+v.size())),std::out_of_range);
	ASSERT_THROWS(v.at(v.size()),std::out_of_range);
}

void testBeginEndInit(){
	Vector<int> v=generateData();
	Vector<double> vd(v.begin(),v.end());
	ASSERT_EQUAL(0.0,vd[1]);
}





void runSuite(){
	cute::suite s;
	//TODO add your test here
	s.push_back(CUTE(testEmptyVector));
	s.push_back(CUTE(testAdressingWithMinus));
	s.push_back(CUTE(testAdressingWithAt));
	s.push_back(CUTE(testAtThrows));
	s.push_back(CUTE(testBeginEndInit));
	cute::ide_listener lis;
	cute::makeRunner(lis)(s, "The Suite");
}

int main(){
    runSuite();
}



