#ifndef VECTOR_H_
#define VECTOR_H_
#include <vector>
template <typename T>
class Vector : public std::vector<T>
{
	typedef std::vector<T> V;
public:
	typedef typename V::iterator iterator;
	typedef typename V::const_iterator const_iterator;
	Vector(){}
	~Vector(){}
	Vector(typename V::size_type sz):V(sz){}
	template <typename InputIterator>
	Vector(InputIterator beg, InputIterator end)
	:V(beg,end){}
	T & operator[](int index)
	{
			return V::operator[](index +
				(index<0?this->size():0));
	}
	T const& operator[](int index)const
	{
			return V::operator[](index +
				(index<0?this->size():0));
	}
	T & at(int index){
		return V::at(index +
				(index<0?this->size():0));
	}
	T const & at(int index) const {
		return V::at(index +
				(index<0?this->size():0));
	}
};
#endif /*VECTOR_H_*/
