#include <iostream>

template <typename T>
void dreitausch(T &a, T& b, T& c){
	T tmp=a;
	a=b; b=c; c=tmp;
}
// Version mit std::swap ist effizienter f�r "grosse" Datenstrukturn
// f�r die std::swap effizient �berladen wurde (z.B. std::vector<T>)
template <typename T>
void tripleswap(T &a, T& b, T& c){
	std::swap(a,b);
	std::swap(b,c);
}
int main(){
	using namespace std;
	int eins(1),zwei(2),drei(3);
    dreitausch(eins,zwei,drei);
    cout << eins<<zwei<<drei<<endl; //--> 231 
    tripleswap(eins,zwei,drei);
    cout << eins<<zwei<<drei<<endl; //--> 312 
    
}
