#include <iostream>
#include <string>

using namespace std;
class Tracer {
	std::string name;
public:
	Tracer(string name):name(name){
		std::cout << "ctor " << name << std::endl;
	}
	~Tracer() {
		std::cout << "dtor " << name << std::endl;
	}
};


int main() {
    Tracer t1("erster");
    {
        Tracer t2("zweiter");
        Tracer t3("dritter");
    }
    Tracer t4("vierter");
}
