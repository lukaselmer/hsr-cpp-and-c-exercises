#ifndef SiebenSegmentZiffer_H_
#define SiebenSegmentZiffer_H_

#include <string>
#include <vector>

class SiebenSegmentZiffer {
public:
	struct invalid_digit{};
	SiebenSegmentZiffer(int digit);
	std::string getDigitLine(int line) const;
	static int const nOfLines=5;
private:
	std::vector<std::string> digitLines;

};

#endif /*SiebenSegmentZiffer_H_*/
