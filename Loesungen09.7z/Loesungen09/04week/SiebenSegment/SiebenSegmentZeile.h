#ifndef SiebenSegmentZeile_H_
#define SiebenSegmentZeile_H_
#include <vector>
#include <iosfwd>
#include "SiebenSegmentZiffer.h"
class SiebenSegmentZeile {
public:
	SiebenSegmentZeile(int zahl);
	void print(std::ostream &out) const;
private:
	std::string getLine(int line)const;
	std::vector<SiebenSegmentZiffer> theDigits;
};
#endif /*SiebenSegmentZeile_H_*/
