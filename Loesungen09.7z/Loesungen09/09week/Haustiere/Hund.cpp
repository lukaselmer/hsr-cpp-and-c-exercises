/*
 * Hund.cpp
 *
 *  Created on: Apr 17, 2009
 *      Author: sop
 */

#include "Hund.h"
#include <iostream>
Hund::Hund(std::string name, bool istKampfhund)
:Haustier(name,"Hund"), istKampfhund(istKampfhund)
{
}

void Hund::gibLaut() const
{
	std::cout << name << ": Wau wau" << std::endl;
}

void Hund::printEigenschaft() const
{
	std::cout << name<< ": " << (istKampfhund?"Grrrrr":"wau") << std::endl;
}






