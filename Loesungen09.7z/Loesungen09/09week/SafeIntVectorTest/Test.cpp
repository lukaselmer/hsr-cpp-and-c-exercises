#include "cute.h"
#include "ide_listener.h"
#include "cute_runner.h"

#include "SafeIntVector.h"
#include <stdexcept>
void testAccessOutOfBoundsWithEmptyVector() {
	SafeIntVector v;
	ASSERT_THROWS(v[0],std::out_of_range);
}
void testAccessWithinBounds(){
	SafeIntVector v(10);
	ASSERT_EQUAL(0,v[9]);
}
void testAccessOutOfBounds(){
	SafeIntVector v(10);
	ASSERT_THROWS(v[10],std::out_of_range);
}
void testAccessNegativeIndexOutOfBounds(){
	SafeIntVector v(10);
	ASSERT_THROWS(v[-1],std::out_of_range);
}void testNormalVectorOperations(){
	SafeIntVector v;
	for(SafeIntVector::size_type i=0; i < 10; ++i)
		v.push_back(i);
	ASSERT_EQUAL(10,v.size());
	ASSERT_EQUAL(9,v[9]);
	v.clear();
	ASSERT(v.empty());
}


void runSuite(){
	cute::suite s;
	//TODO add your test here
	s.push_back(CUTE(testAccessOutOfBoundsWithEmptyVector));
	s.push_back(CUTE(testAccessWithinBounds));
	s.push_back(CUTE(testAccessOutOfBounds));
	s.push_back(CUTE(testAccessNegativeIndexOutOfBounds));
	s.push_back(CUTE(testNormalVectorOperations));
	cute::ide_listener lis;
	cute::makeRunner(lis)(s, "The Suite");
}

int main(){
    runSuite();
}



