#include "Person.h"
#include <iostream>
using namespace std;

int main() {
	Person mensch1("Adam");
	Person mensch2("Eva");
	Person* pMensch3 = new Person("Abel", &mensch1, &mensch2);
	Person mensch4("Kain", &mensch1, &mensch2);
	Person mensch5("Seth", &mensch1, &mensch2);
	Person mensch6("Enosch", &mensch5, 0);

	cout << mensch1 << endl;
	cout << mensch2 << endl;
	cout << *pMensch3 << endl;
	cout << mensch4 << endl;
	cout << mensch5 << endl;

	cout << "Sorry " << pMensch3->getName() << "!" << endl;
	delete pMensch3;

	cout << mensch1 << endl;
}
