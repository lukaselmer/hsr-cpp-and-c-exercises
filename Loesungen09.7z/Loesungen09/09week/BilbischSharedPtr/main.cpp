#include "Person.h"
#include <iostream>
using namespace std;

int main() {
	PersonPtr mensch1 = Person::make("Adam");
	PersonPtr mensch2 = Person::make("Eva");
	PersonPtr mensch3 = Person::make("Abel", mensch1, mensch2);
	PersonPtr mensch4 = Person::make("Kain", mensch1, mensch2);
	PersonPtr mensch5 = Person::make("Seth", mensch1, mensch2);
	PersonPtr mensch6 = Person::make("Enosch", mensch5, PersonPtr() );

	cout << mensch1 << endl;
	cout << mensch2 << endl;
	cout << mensch3 << endl;
	cout << mensch4 << endl;
	cout << mensch5 << endl;

	cout << "Sorry " << mensch3->getName() << "!" << endl;
	Person::kill(mensch3);
	cout << mensch1 << endl;

	cout << "Sorry " << mensch1->getName() << "!" << endl;
	Person::kill(mensch1);
	cout << mensch4 << endl;

	return 0;
}
