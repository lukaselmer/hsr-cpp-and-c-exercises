#ifndef PERSON_H_
#define PERSON_H_
#include <vector>
#include <string>
#include <iosfwd>
#include <boost/shared_ptr.hpp>
typedef boost::shared_ptr<class Person> PersonPtr;
class Person
{
	std::string name;
	PersonPtr vater;
	PersonPtr mutter;
	std::vector<PersonPtr> kinder;
	Person(std::string nam,PersonPtr vati, PersonPtr mutti);
public:
	static PersonPtr make(std::string nam,PersonPtr vati=PersonPtr(), PersonPtr mutti=PersonPtr());
	static void kill(PersonPtr &culprit);
	~Person();
	std::string getName() const ;
	void setKind(PersonPtr kind);
	void loescheKinder();
	void print(std::ostream &os) const;
	void printEltern(std::ostream&os) const;
	void printKinder(std::ostream&os) const;
private:
	void loescheKind(PersonPtr totesKind);
	void loescheElternTeilBeiKind(PersonPtr toterElternteil);
	void loescheElternTeilBeiKindern(PersonPtr toterElternteil);
	Person(Person const &);
	Person& operator=(Person const&);
};
std::ostream& operator<<(std::ostream& os,PersonPtr const &p);
#endif /*PERSON_H_*/
