/*
 * LinkedList.cpp
 *
 *  Created on: Apr 1, 2009
 *      Author: sop
 */

#include "LinkedList.h"
#include <stdexcept>
LinkedList::LinkedList():first(0),last(0) {
}

LinkedList::~LinkedList() {
	delete first;
}

bool LinkedList::empty() const
{
	return first==0;
}

void LinkedList::push_front(int value)
{
	first = new Node(value,first);
	if (!last) last=first;
}

void LinkedList::pop_front()
{
	Node *old= first;
	if (first) first = first->next;
	if (!first) last=0;
	if (old) old->next=0;
	else throw std::logic_error("list empty");
	delete old;
}

void LinkedList::push_back(int value)
{
	if (!last) push_front(value);
	else {
		last->next = new Node(value,0);
		last = last->next;
	}
}

int LinkedList::back() const
{
	if (last) return last->value;
	throw std::out_of_range("access to empty list");
}

void LinkedList::pop_back()
{
	if (!last) throw std::logic_error("list empty");
	Node *old=last;
	if (last == first) last = first =0;
	else {
		for (last = first; last->next != old; last = last->next);
		last->next=0;
	}
	delete old;
}

int LinkedList::front() const
{
	if (first) return first->value;
	throw std::out_of_range("access to empty list");
}

LinkedList::Node::Node(int value, Node *node)
:value(value),next(node){
}

LinkedList::Node::~Node()
{
	delete next;
}

LinkedList::LinkedList(const LinkedList & l)
:first(0),last(0)
{
	// deep copy
	Node *n=l.first;
	while(n){
		push_back(n->value);
		n= n->next;
	}
}

bool LinkedList::contains(int value) const
{
	Node *next=first;
	while (next){
		if(next->value == value) return true;
		next=next->next;
	}
	return false;
}

void LinkedList::insertBefore(int key, int value)
{
	if (empty()) throw std::logic_error("empty list");
	if (first->value == key){
		push_front(value);
		return;
	}
	Node *next = first;
	while(next->next && next->next->value != key){
		next = next->next;
	}
	if (next->next)
		next->next=new Node(value,next->next);
	else
		throw std::logic_error("key not in list");
}

void LinkedList::insertAfter(int key, int value)
{
	if (empty()) throw std::logic_error("empty list");
	Node *next=first;
	while(next && next->value != key) next=next->next;
	if (next)
		next->next=new Node(value,next->next);
	else
		throw std::logic_error("key not in list");
}
















