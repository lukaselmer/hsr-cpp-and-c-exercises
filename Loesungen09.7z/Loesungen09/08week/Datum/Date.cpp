
#include "Date.h"
#include <iostream>
#include <sstream>
#include <iomanip>
#include <stdexcept>
char const * const Date::months[]={
		"JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEZ"
};
unsigned const Date::maxDayInMonth[]={
		31,29,31,30,31,30,31,31,30,31,30,31
};


bool Date::isValidMonth() const
{
    return month >= 1 && month <= 12;
}

Date::Date(unsigned tag, unsigned mon, unsigned year)
:day(tag),month(mon),year(year)
{
	if (!isValidMonth() ||
			! isValidDayInMonth())
		throw std::range_error("invalid date");
}

std::ostream & operator <<(std::ostream & os, const Date & d)
{
	os << d.toString();
	return os;
}

std::string Date::getMonthAsString() const
{
	return months[month-1];
}

bool Date::isLeapYear() const
{
	return year%4 == 0;
}

bool Date::isValidDayInMonth() const
{
	return !(day < 1 || day > getMaxDayInMonth());
}

std::string Date::toString() const
{using namespace std;
	std::ostringstream os;
	os << setw(2) << setfill('0')<< day <<". "
	<< getMonthAsString() <<" "
	<< setw(4) << year;
	return os.str();
}

unsigned Date::getMaxDayInMonth() const
{
	if (month==2 && !isLeapYear())
		return 28;
	return maxDayInMonth[month-1];
}

Date & Date::operator+=( unsigned  step)
{
	day += step;
	while(day > getMaxDayInMonth()){
		day -= getMaxDayInMonth();
		if (++month > 12) {
			month=1;
			++year;
		}
	}
	return *this;
}






