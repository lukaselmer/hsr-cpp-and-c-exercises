#ifndef DATE_H_
#define DATE_H_
#include <iosfwd>
#include <string>
class Date {
	unsigned day,month,year;
	static const char *const months[];
    static unsigned const maxDayInMonth[];
    std::string getMonthAsString() const;
    unsigned getMaxDayInMonth() const;
    bool isLeapYear() const;
    bool isValidMonth() const;
    bool isValidDayInMonth() const;
public:
	Date(unsigned tag,unsigned mon, unsigned year);
	std::string toString() const;
	Date& operator+=(unsigned step);
	Date& operator++() {  return *this+=1; }
};
std::ostream& operator<<(std::ostream &os,Date const &d);

#endif /* DATE_H_ */
