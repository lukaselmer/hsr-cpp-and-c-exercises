#include "cute.h"
#include "ide_listener.h"
#include "cute_runner.h"
#include "Date.h"
#include <sstream>
void testDateCtor() {
	Date aprilApril(1, 4, 2009);
	ASSERT_EQUAL("01. APR 2009",aprilApril.toString());
}

void testNextDay() {
	Date d(31, 3, 2009);
	ASSERT_EQUAL("31. MAR 2009",d.toString());
	d += 1;
	ASSERT_EQUAL("01. APR 2009",d.toString());
}

void testNextDaySilvester() {
	Date d(31, 12, 2008);
	++d;
	ASSERT_EQUAL("01. JAN 2009",d.toString());
}

void testLeapYearJump() {
	Date d(20, 2, 2008);
	d += 29;
	ASSERT_EQUAL("20. MAR 2008",d.toString());
}

void testLeapYearJumpAcrossSilvester() {
	Date d(29, 2, 2008);
	d += 731; // leap year + regular year
	ASSERT_EQUAL("01. MAR 2010",d.toString());
}

void testLeapYearJumpToLeapDay() {
	Date d(1, 3, 2007);
	d += 365;
	ASSERT_EQUAL("29. FEB 2008", d.toString());
}
void testInvalidDate(){
	ASSERT_THROWS(Date(29,2,2009),std::range_error);
	ASSERT_THROWS(Date(0,1,0),std::range_error);
	ASSERT_THROWS(Date(1,0,1000),std::range_error);
	ASSERT_THROWS(Date(1,13,2000),std::range_error);
	ASSERT_THROWS(Date(31,11,2009),std::range_error);
}


void runSuite() {
	cute::suite s;
	//TODO add your test here
	s.push_back(CUTE(testDateCtor));
	s.push_back(CUTE(testNextDay));
	s.push_back(CUTE(testNextDaySilvester));
	s.push_back(CUTE(testLeapYearJump));
	s.push_back(CUTE(testLeapYearJumpAcrossSilvester));
	s.push_back(CUTE(testLeapYearJumpToLeapDay));
	s.push_back(CUTE(testInvalidDate));
	cute::ide_listener lis;
	cute::makeRunner(lis)(s, "The Suite");
}

int main() {
	runSuite();
}

