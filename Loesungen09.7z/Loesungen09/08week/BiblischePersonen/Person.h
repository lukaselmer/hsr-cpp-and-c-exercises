#ifndef PERSON_H_
#define PERSON_H_
#include <iostream>
#include <vector>
#include <string>
#include <iosfwd>
class Person
{
	std::string name;
	Person *vater;
	Person *mutter;
	std::vector<Person *> kinder;
public:
	Person(std::string nam,Person *vati=0, Person *mutti=0);
	~Person();
	void setKind(Person *kind);
	void removeKind(Person *kind);
	void print(std::ostream &os)const ;
	void printEltern(std::ostream&os) const;
	void printKinder(std::ostream&os) const;
private:
	Person(Person const &);
	Person& operator=(Person const&);
};
std::ostream&operator<<(std::ostream& os,Person const &p);
#endif /*PERSON_H_*/
