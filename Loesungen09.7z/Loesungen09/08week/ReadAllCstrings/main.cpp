#include <iostream>
#include <cstring>
#include <cstddef>
char * readall(std::istream &in) {
    char  line[1000];
    char *all= (char*)::calloc(1,1);

    while (in){
    	 in.getline(line,sizeof(line));
    	 if (in.fail()&&!in.eof()) in.clear(); // too long line
         char *news = (char*)::calloc(strlen(all)+strlen(line)+1,1);
         ::strcat(news,all);
         ::strcat(news,line);
         ::free(all);
         all=news;
    }
    return all;
}


int main(){
	char *s=readall(std::cin);
	::free(s);
}
