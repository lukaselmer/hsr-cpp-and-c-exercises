#include "Wort.h"
#include <cctype>
#include <iostream>
using namespace std;
istream &operator>>(istream &is,Wort &w){
	w.readFrom(is);
	return is;
}
void Wort::readFrom(istream &is){
	string s;
	istream::char_type c='\0';
	while(is.get(c) && !isalpha(c)); // skip over non-letters
	is.putback(c);
	while(is.get(c) && isalpha(c)) s.push_back(c);
	if (is) is.putback(c); // read one char too much
	else if (!s.empty()) is.clear(); // clear eof for last word
	wort=s;
}
//for algorithm lexicographical_compare
namespace{
bool caselesscompare(char l, char r) {
	return toupper(l) < toupper(r);
}
}
bool Wort::operator<(Wort const & rhs) const {
	return lexicographical_compare(wort.begin(),wort.end(),rhs.wort.begin(),rhs.wort.end(),caselesscompare);
}

