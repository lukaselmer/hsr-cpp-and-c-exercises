#ifndef RATIONAL_H_
#define RATIONAL_H_
#include <iosfwd>
class Rational
{
public:
	Rational(int zaehl=0, int nenn=1);
	Rational& operator+=(const Rational&);
	void print(std::ostream &os)const;
private:
	long zaehler;
	long nenner;
};
Rational operator+(const Rational &left,const Rational&right);

Rational operator+(int,const Rational&right);
std::ostream& operator<<(std::ostream &,const Rational &);
#endif /*RATIONAL_H_*/
