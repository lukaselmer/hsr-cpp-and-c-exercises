#include "Rational.h"
#include <iostream>

Rational::Rational(int zaehl, int nenn)
:zaehler(zaehl),nenner(nenn){}

void Rational::print(std::ostream &out) const {
	out << zaehler << '/' << nenner;
}

Rational& Rational::operator+=(const Rational&rhs){
	zaehler = (zaehler * rhs.nenner) + (rhs.zaehler * nenner);
	nenner *= rhs.nenner;
	return *this;
}
Rational operator+(const Rational &left,const Rational&right){
	Rational result(left);
	result += right;
	return result;
}
Rational operator+(int left,const Rational&right){
	Rational result(left);
	result += right;
	return result;
}
std::ostream& operator<<(std::ostream &os,const Rational &r){
	r.print(os);
	return os;
}

