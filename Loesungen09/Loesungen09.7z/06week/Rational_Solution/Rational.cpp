#include "Rational.h"
#include <iostream>

Rational::Rational(int zaehl, int nenn)
:zaehler(zaehl),nenner(nenn){ normalize();}

void Rational::print(std::ostream &out) const {
	out << zaehler << '/' << nenner;
}

Rational& Rational::operator+=(const Rational&rhs){
	zaehler = (zaehler * rhs.nenner) + (rhs.zaehler * nenner);
	nenner *= rhs.nenner;
	normalize();
	return *this;
}
Rational& Rational::operator-=(const Rational&rhs){
	zaehler = (zaehler * rhs.nenner) - (rhs.zaehler * nenner);
	nenner *= rhs.nenner;
	normalize();
	return *this;
}
Rational& Rational::operator*=(const Rational&rhs){
	zaehler *= rhs.zaehler;
	nenner *= rhs.nenner;
	normalize();
	return *this;
}
Rational& Rational::operator/=(const Rational&rhs){
	zaehler *= rhs.nenner;
	nenner *= rhs.zaehler;
	normalize();
	return *this;
}
Rational operator+(const Rational&lhs,const Rational&rhs){
	Rational result(lhs);
	result += rhs;
	return result;
}
Rational operator-(const Rational&lhs,const Rational&rhs){
	Rational result(lhs);
	result -= rhs;
	return result;
}
Rational operator*(const Rational&lhs,const Rational&rhs){
	Rational result(lhs);
	result *= rhs;
	return result;
}
Rational operator/(const Rational&lhs,const Rational&rhs){
	Rational result(lhs);
	result /= rhs;
	return result;
}
Rational::operator double() const {
	return static_cast<double>(zaehler) / nenner;
}
Rational::operator float() const {
	return static_cast<float>(zaehler) / nenner;
}
Rational::operator int() const {
	return zaehler / nenner; // no rounding...
}


std::ostream& operator<<(std::ostream&os, const Rational&r){
	r.print(os);
	return os;
}
std::istream& operator>>(std::istream&is,Rational &r){
	r.read(is);
	return is;
}

namespace{

long gcd(long n, long m){
	if (n < 0) n = -n;
	if (m < 0) m = -m;
	while(1){
		if (0 ==m) return n;
		n %= m;
		if (0 == n) return m;
		m %= n;
	}
}
}
bool Rational::operator ==(const Rational & other) const
{
	return other.nenner == nenner && other.zaehler == zaehler;
}


bool Rational::operator <(const Rational & other) const
{
	return static_cast<double>(*this)<static_cast<double>(other);
}


void Rational::normalize(){
	if (0 == nenner) throw bad_rational();
	if (0 == zaehler) {
		nenner = 1;
		return;
	}
	long teiler = gcd(zaehler,nenner);
	zaehler /= teiler;
	nenner /= teiler;
	if (nenner < 0) {
		nenner = -nenner;
		zaehler = -zaehler;
	}
}
void Rational::read(std::istream &is){
	char c; long zaehler=0,nenner=1;
	is >> zaehler>>c>>nenner;
	if (is && '/' == c) *this = Rational(zaehler,nenner);
	else {
		is.setstate(std::ios_base::failbit);
		throw bad_rational();
	}
}

