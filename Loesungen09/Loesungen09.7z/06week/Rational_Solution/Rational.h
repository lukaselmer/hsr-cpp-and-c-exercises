#ifndef RATIONAL_H_
#define RATIONAL_H_
#include <iosfwd>
class Rational
{
	public:
	class bad_rational{};
	explicit Rational(int zaehl=0, int nenn=1);
	Rational& operator+=(Rational const&);
	Rational& operator-=(Rational const&);
	Rational& operator*=(Rational const&);
	Rational& operator/=(Rational const&);
	bool operator==(Rational const&)const;
	bool operator<(Rational const&)const;
	void print(std::ostream &os)const;
	void read(std::istream &is);
	// week 7:
	operator double()const;
	operator float()const;
	operator int()const;

	private:
	void normalize();
	long zaehler;
	long nenner;
};

Rational operator+(const Rational&lhs,const Rational&rhs);
Rational operator-(const Rational&lhs,const Rational&rhs);
Rational operator*(const Rational&lhs,const Rational&rhs);
Rational operator/(const Rational&lhs,const Rational&rhs);
std::ostream& operator<<(std::ostream&os, const Rational&r);
std::istream& operator>>(std::istream&is, Rational&r);
#endif /*RATIONAL_H_*/
