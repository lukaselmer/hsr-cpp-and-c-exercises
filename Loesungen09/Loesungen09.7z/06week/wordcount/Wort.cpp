#include "Wort.h"
#include <cctype>
#include <iostream>
using namespace std;
istream &operator>>(istream &is, Wort &w) {
	w.readFrom(is);
	return is;
}
void Wort::readFrom(istream &is) {
	string s;
	istream::char_type c = '\0';
	while (is.get(c) && !isalpha(c))
		; // skip over non-letters
	is.putback(c);
	while (is.get(c) && isalpha(c))
		s.push_back(c);
	if (is)
		is.putback(c); // read one char too much
	else if (!s.empty())
		is.clear(); // clear eof for last word
	wort = s;
}

