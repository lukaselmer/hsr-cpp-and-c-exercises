#include <iostream>
#include <iterator>
#include <numeric>
#include <vector>
int main() {
	std::vector<int> v(std::istream_iterator<int>(std::cin),std::istream_iterator<int>());
	std::cout << std::accumulate(v.begin(),v.end(),0)/v.size() << std::endl;
//	int summe=0;
//	int count=0;
//	int input;
//	while (std::cin>>input){
//		summe += input;
//		++count;
//	}
//	std::cout << summe/count << std::endl;

}
