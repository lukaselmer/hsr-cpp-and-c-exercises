#include "calc.h"

int calc(int x, int y, char oper){
	switch(oper){
	case '+': return x+y;
	case '-': return x-y;
	case '*': return x*y;
	case '/': return y!=0?x/y:0; // avoid crashes
	}
	return x+y;
}
