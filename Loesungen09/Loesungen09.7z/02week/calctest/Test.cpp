#include "cute.h"
#include "ide_listener.h"
#include "cute_runner.h"
#include "calc.h"

void calcTestAdd1and1() {
	ASSERT_EQUAL(2,calc(1,1,'+'));
}
void calcTestAdd2and3() {
	ASSERT_EQUAL( 5, calc( 2, 3, '+'));
}
void calcTestAddnegative(){
	ASSERT_EQUAL(-5, calc(-2, -3, '+'));
}
void clacTestAddZero() {
	ASSERT_EQUAL(17, calc( 0, 17, '+'));
}
void calcTestAddCommutative() {
	ASSERT_EQUAL(calc(2, 3, '+'), calc( 3, 2, '+'));
}
void calcTestAddSignWrapToNegative(){
	ASSERT(calc(1073741824, 1073741824, '+') < 0);
}
void calcTestAddMinusNoSignWrap(){
	ASSERT(calc(-1073741824, -1073741824, '+') < 0);
}
void calcTestAddBorders() {
	ASSERT_EQUAL( 2147483648UL, calc( 1073741824, 1073741824, '+'));
}
void calcTestSub() {
	ASSERT_EQUAL( 2, calc( 5, 3, '-'));
}
void calcTestSubNegative(){
	ASSERT_EQUAL(-10,calc(-15,-5,'-'));
}
void calcTestSubZero() {
	ASSERT_EQUAL(17, calc(17,0, '-'));
}
void calcTestMul() {
	ASSERT_EQUAL( 6, calc( 2, 3, '*'));
}
void calcTestMulNegativeNegativeIsPositive(){
	ASSERT_EQUAL( 6, calc(-2, -3, '*'));
}
void calcTestMulNegative(){
	ASSERT_EQUAL( -6, calc(-2, 3, '*'));
}
void calcTestMulZero() {
	ASSERT_EQUAL(0, calc(5, 0, '*'));
}
void calcTestMulInert() {
	ASSERT_EQUAL( 17, calc(17, 1, '*'));
}
void calcTestMulCommutative() {
	ASSERT_EQUAL(calc(5, 2, '*'), calc( 2, 5, '*'));
}
void calcTestDiv() {
	ASSERT_EQUAL( 2, calc( 6, 3, '/'));
}
void calcTestDivZero() {
	ASSERT_EQUAL(0, calc(0, 5, '/'));
	//ASSERT_EQUAL(0, calc(5, 0, '/'));
	//ASSERT_EQUAL(0, calc(0, 0, '/'));
}
void calcTestDivInert() {
	ASSERT_EQUAL(17, calc(17, 1, '/'));
}
void calcTestDivCutOff() {
	ASSERT_EQUAL( 1, calc( 5, 3, '/'));
}

void runSuite() {
	cute::suite s;
	//TODO add your test here
	s.push_back(CUTE(calcTestAdd1and1));
	s.push_back(CUTE(calcTestAdd2and3));
	s.push_back(CUTE(calcTestAddnegative));
	s.push_back(CUTE(clacTestAddZero));
	s.push_back(CUTE(calcTestAddCommutative));
	s.push_back(CUTE(calcTestAddSignWrapToNegative));
	s.push_back(CUTE(calcTestAddMinusNoSignWrap));
	s.push_back(CUTE(calcTestAddBorders));

	s.push_back(CUTE(calcTestSub));
	s.push_back(CUTE(calcTestSubZero));
	s.push_back(CUTE(calcTestSubNegative));

	s.push_back(CUTE(calcTestMul));
	s.push_back(CUTE(calcTestMulZero));
	s.push_back(CUTE(calcTestMulNegativeNegativeIsPositive));
	s.push_back(CUTE(calcTestMulNegative));
	s.push_back(CUTE(calcTestMulCommutative));
	s.push_back(CUTE(calcTestMulInert));

	s.push_back(CUTE(calcTestDiv));
	s.push_back(CUTE(calcTestDivZero));
	s.push_back(CUTE(calcTestDivInert));
	s.push_back(CUTE(calcTestDivCutOff));

	cute::ide_listener lis;
	cute::makeRunner(lis)(s, "The Suite");
}

int main() {
	runSuite();
}

