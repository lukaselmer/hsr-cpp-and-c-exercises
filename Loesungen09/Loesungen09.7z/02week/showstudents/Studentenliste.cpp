#include "Studentenliste.h"
#include <iostream>
#include <string>
#include <set>
#include <algorithm>
#include <iterator>

void showStudents(std::istream &in){
	std::set<std::string> liste;
	std::string line;
	while (std::getline(in,line)){
		liste.insert(line);
	}
	copy(liste.begin(),liste.end(),std::ostream_iterator<std::string>(std::cout,"\n"));
}
