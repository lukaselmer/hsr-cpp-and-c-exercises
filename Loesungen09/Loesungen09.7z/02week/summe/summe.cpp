#include <iostream>
#include <iterator>
#include <numeric>

int main() {
	int summe=0;
	int input;
	while (std::cin>>input){
		summe += input;
	}
	std::cout << summe << std::endl;
//	std::cout <<
//		std::accumulate(std::istream_iterator<int>(std::cin),
//				        std::istream_iterator<int>(), 0)
//	<< std::endl;
}
