#ifndef SIEBENSEGMENT_H_
#define SIEBENSEGMENT_H_

#include <iosfwd>
#include <string>
void printLargeDigit(int i, std::ostream& out);
std::string getDigitLine(int i, int line);



#endif /* SIEBENSEGMENT_H_ */
