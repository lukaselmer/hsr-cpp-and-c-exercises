#include <iostream>
#include <iterator>
#include <algorithm>
#include <string>
#include <map>
int main(){
	using namespace std;
	const string vokale("aeiou");
	// // Variante 1 mehrfach count:
//	istreambuf_iterator<char> eof;
//	string all(istreambuf_iterator<char>(cin),eof);
//	for (string::const_iterator vokal=vokale.begin();vokal!=vokale.end();++vokal) {
//		cout << count(all.begin(),all.end(),*vokal)<< " " << *vokal<<endl;
//	}
	// Variante 2 mit map:
	map<char,int> allcounters;
	char input;
	while(cin>>input){
		++allcounters[input];
	}
	for (string::const_iterator vokal=vokale.begin();vokal!=vokale.end();++vokal) {
		cout << allcounters[*vokal] << " " << *vokal<<endl;
	}

}

