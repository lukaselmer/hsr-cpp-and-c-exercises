#include <iostream>
#include <string>
#include <map>
#include <iterator>

int main(){
	using namespace std;
	map<string,int> words;
	string input;
	while (cin >> input)
		++words[input];
	for (map<string,int>::iterator it=words.begin();it!=words.end();++it){
		cout << it->first << " : " << it->second << endl;
	}
}
