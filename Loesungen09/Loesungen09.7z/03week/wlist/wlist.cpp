#include <iostream>
#include <string>
#include <set>
#include <iterator>
int main(){
	using namespace std;
	istream_iterator<string> eof;
	set<string> wordlist(istream_iterator<string>(cin),eof);
	copy(wordlist.begin(),wordlist.end(),ostream_iterator<string>(cout,"\n"));
}
