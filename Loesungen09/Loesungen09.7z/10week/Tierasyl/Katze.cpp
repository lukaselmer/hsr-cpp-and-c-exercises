#include "Katze.h"
#include <iostream>

Katze::Katze(std::string name, std::string schmusefaktor)
:Haustier(name,"Katze"),schmusefaktor(schmusefaktor){
}


void Katze::gibLaut() const
{
	std::cout <<name<< ": Miau miau" <<std::endl;
}

void Katze::printEigenschaft(std::ostream &out) const
{
	out << name << ": " << schmusefaktor << std::endl;
}


