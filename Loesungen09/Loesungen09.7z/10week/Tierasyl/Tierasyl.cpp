#include "Tierasyl.h"
#include <ostream>
void Tierasyl::liefereAb(TierPtr tier)
{
	asyl[tier->getName()] = tier;
}

TierPtr Tierasyl::holeAb(std::string name)
{
	TierPtr res = asyl[name];
	asyl.erase(name);
	return res;
}

namespace {
struct PairPrinter{
	std::ostream &out;
	PairPrinter(std::ostream &os):out(os){}
	void operator()(Tierasyl::Asyl::value_type const &pair){
			out << pair.second->getName();
	}
};

}

void Tierasyl::print(std::ostream & os) const
{
	for_each(asyl.begin(),asyl.end(),PairPrinter(os));
}

std::ostream & operator <<(std::ostream & os, const Tierasyl & tierasyl)
{
	tierasyl.print(os);
	return os;
}
std::string selectFirst(std::pair<std::string,TierPtr> const &p){
	return p.first;
}

std::vector<std::string> Tierasyl::tierNamen() const
{
	std::vector<std::string> result;
	std::transform(asyl.begin(),asyl.end(),std::back_inserter(result),
			selectFirst);
	return result;
}










