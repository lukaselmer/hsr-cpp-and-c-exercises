#ifndef KATZE_H_
#define KATZE_H_

#include "Haustier.h"

class Katze: public Haustier {
std::string schmusefaktor;
public:
	Katze(std::string name, std::string schmusefaktor);
	virtual void gibLaut() const;
	virtual void printEigenschaft(std::ostream &os) const;
};

#endif /* KATZE_H_ */
