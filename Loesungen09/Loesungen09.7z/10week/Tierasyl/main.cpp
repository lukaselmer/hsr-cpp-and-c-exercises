#include "Haustier.h"
#include "Hund.h"
#include "Katze.h"
#include "Tierasyl.h"
#include <vector>
#include <functional>
#include <iostream>
#include <boost/bind.hpp>

struct GibLaut {
	void operator()(TierPtr tier){
		tier->gibLaut();
	}
};
struct LiefereAb{
	Tierasyl &asyl;
	LiefereAb(Tierasyl &asyl):asyl(asyl){}
	void operator()(TierPtr tier){
		asyl.liefereAb(tier);
	}
};

void fuelleTierasyl(Tierasyl &asyl, std::vector<TierPtr> &tiere){
	for_each(tiere.begin(),tiere.end(),LiefereAb(asyl));
	tiere.clear();
}

void holeAusAsyl(Tierasyl &asyl, std::vector<TierPtr> &tiere){
	std::vector<std::string> tiernamen = asyl.tierNamen();
	std::cout << tiernamen.size() << " tiere im Asyl " << std::endl;
	transform(tiernamen.begin(),tiernamen.end(),std::back_inserter(tiere),
			boost::bind(&Tierasyl::holeAb,boost::ref(asyl),_1));
}

void tierAusgabe(std::vector<TierPtr> & alleTiere)
{
    for_each(alleTiere.begin(), alleTiere.end(), boost::bind(&Haustier::printName, _1));
}

void alleTiereGebenLaut(std::vector<TierPtr> & alleTiere)
{
    for_each(alleTiere.begin(), alleTiere.end(),
    		boost::bind(std::mem_fun(&Haustier::gibLaut),
    				boost::bind(&boost::shared_ptr<Haustier>::get, _1)));
// simpler:
    for_each(alleTiere.begin(), alleTiere.end(), GibLaut());


}

int main(){
	std::vector<TierPtr> alleTiere;
	alleTiere.push_back(TierPtr(new Hund("Lassie",false)));
	alleTiere.push_back(TierPtr(new Hund("Fass!",true)));
	alleTiere.push_back(TierPtr(new Katze("Mikesch","schmust gerne")));
	alleTiere.push_back(TierPtr(new Katze("PussInBoots","fechtet gerne")));
	alleTiere.push_back(TierPtr(new Katze("Streuner","kratzt")));

	std::cout << "Es gibt Futter\n";
    alleTiereGebenLaut(alleTiere);
	// besser
	std::cout << "Alle meine Tiere\n";
    tierAusgabe(alleTiere);
	std::cout << "Ihre Eigenschaften:\n";
	for_each(alleTiere.begin(),alleTiere.end(),
			boost::bind(&Haustier::printEigenschaft,_1,boost::ref(std::cout)));
	///
	Tierasyl asyl;
	fuelleTierasyl(asyl, alleTiere);
	std::cout << "\nalle meine Tiere zuhause: ";
	tierAusgabe(alleTiere);
	std::cout << "\nasyl: " << asyl << std::endl;
	holeAusAsyl(asyl,alleTiere);
	std::cout << "\nasyl: " << asyl << std::endl;
	std::cout << "alle meine Tiere zuhause: ";
	tierAusgabe(alleTiere);

	alleTiere.clear();
}
