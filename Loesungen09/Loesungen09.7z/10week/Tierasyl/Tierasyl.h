#ifndef TIERASYL_H_
#define TIERASYL_H_
#include "Haustier.h"
#include <map>
#include <vector>
#include <iosfwd>
class Tierasyl {
public:
	typedef std::map<std::string,TierPtr> Asyl;
    void liefereAb(TierPtr tier );
    TierPtr holeAb(std::string name);
    void print(std::ostream& os)const;
    std::vector<std::string> tierNamen() const;
private:
	Asyl asyl;
};
std::ostream& operator<<(std::ostream& os,Tierasyl const &);

#endif /* TIERASYL_H_ */
