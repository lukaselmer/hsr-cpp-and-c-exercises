#include <iostream>
#include <iterator>
#include <string>
#include <set>
#include <map>
#include <algorithm>
#include <ext/algorithm> // for random_select
template <unsigned int length>
class Schnipsel{
	template <int size>
	struct cmpFixedSize {
		bool operator()(std::string s1, std::string s2){
			s1.resize(size,' ');
			s2.resize(size,' ');
			return s1 < s2;
		}
	};
	typedef std::multiset<std::string,cmpFixedSize<length-1> > schnipsel_type;
	schnipsel_type	schnipsel;
	typedef typename schnipsel_type::const_iterator schnipsiter;
	void insertSchnipsel(std::string::const_iterator it){
		schnipsel.insert(std::string(it,it+length));
	}
	template <typename Iter>
	std::string randomSelect(Iter begin, Iter end){
		using namespace __gnu_cxx;
		std::string s; // for ramdom_sample
		random_sample_n(begin,end,&s,1);
		return s;
	}

public:

Schnipsel(std::string const &text)
{
	std::string::const_iterator it=text.begin();
	while (it != text.end()-length){
		insertSchnipsel(it);
		++it;
	}
}
	std::string getFirstSchnipsel(){
		return randomSelect(schnipsel.begin(),schnipsel.end());
	}
	char getNextChar(std::string last){
		const int relevantLength=length-1;
		std::string theComparable=last.substr(last.size()-relevantLength,relevantLength);
		std::pair<schnipsiter,schnipsiter> range=
			schnipsel.equal_range(theComparable);
		if (std::distance(range.first,range.second))
			return randomSelect(range.first,range.second)[length-1];
		return ' ';//nothing found return blanks
	}
	void appendNextSchnipsel(std::string &text){
		text += getNextChar(text.substr(text.size()-length,length));
	}
	void dump(){
		std::copy(schnipsel.begin(),schnipsel.end(),
		std::ostream_iterator<typename schnipsel_type::value_type>(std::cout,"\n"));
	}
};
char nl_to_blank(char c){
	return (c == '\n')?' ':c;
}
int main(){
	srand(time(0)); // make it more random.
	using namespace std;
	string text;
	istreambuf_iterator<char> eof;
	istreambuf_iterator<char> in(cin);
	transform(in,eof,back_inserter(text),nl_to_blank);
	Schnipsel<3> schnipsel(text);
	string first = schnipsel.getFirstSchnipsel();
	while(first.size()<200) schnipsel.appendNextSchnipsel(first);
	cout << "result:\n"<<first<<endl;
}

