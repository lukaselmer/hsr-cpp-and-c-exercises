#include <iostream>
#include <vector>
#include <algorithm>
#include <boost/assign.hpp>

int main() {
	using namespace std;
	using namespace boost::assign;
	vector<int> v;
	v += 1,2,3,4,5;
	unsigned int count(0);
	do {
		cout << ++count << ": " ;
		copy(v.begin(),v.end(),ostream_iterator<int>(cout,", "));
		cout << endl;
	}while (next_permutation(v.begin(),v.end()));
	cout << count << " Permutationen" << endl;
	// 120 Permutationen
	// mit next_permutation(v.rbegin(),v.rend()) sofortiger Abbruch, weil "sortiert"
}
