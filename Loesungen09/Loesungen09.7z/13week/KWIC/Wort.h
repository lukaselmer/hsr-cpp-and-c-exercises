#ifndef Wort_H_
#define Wort_H_
#include <string>
#include <iosfwd>
class Wort {
	std::string	wort;
public:
	Wort(std::string s=""):wort(s){}
	bool operator<(const Wort&rhs)const;
	void print(std::ostream&) const;
	void readFrom(std::istream&);
	std::string::size_type size() const {return wort.size();}
};
std::istream& operator>>(std::istream&,Wort&);
std::ostream& operator<<(std::ostream&,const Wort&);
#endif
