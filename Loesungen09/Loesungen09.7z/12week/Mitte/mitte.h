#ifndef MITTE_H_
#define MITTE_H_

template <typename T>
T const &mitte(T const &a, T const &b, T const &c){
	if (a < b) {
		if (b < c) return b;
		else if (a < c) return c;
		else return a;
	} else {
		if (a < c) return a;
		else if (b < c) return c;
		else return b;
	}
}
// Overload f. Pointertypen, Wertvergleich, nicht Adressen
template <typename T>
T const *mitte(T const *a, T const *b, T const *c){
	if (*a < *b) {
		if (*b < *c) return b;
		else if (*a < *c) return c;
		else return a;
	} else {
		if (*a < *c) return a;
		else if (*b < *c) return c;
		else return b;
	}
}
#include <cstring> /* f. strcmp() */
//Overload f. C-artige Strings, k�nnte auch std::string nutzen...
char const *mitte(char const *a, char const *b, char const *c){
	if (strcmp(a, b)<0) {
		if (strcmp(b,c) < 0) return b;
		else if (strcmp(a,c) < 0) return c;
		else return a;
	} else {
		if (strcmp(a,c) < 0) return a;
		else if (strcmp(b,c) < 0) return c;
		else return b;
	}
}

#endif /* MITTE_H_ */
