#ifndef VECTOR_H_
#define VECTOR_H_
#include <vector>
template <typename T>
class Vector
{
	typedef std::vector<T> V;
	V v;
public:
	typedef typename V::size_type size_type;
	typedef typename V::iterator iterator;
	typedef typename V::const_iterator const_iterator;
	Vector(){}
	~Vector(){}
	Vector(typename V::size_type sz):v(sz){}
	template <typename InputIterator>
	Vector(InputIterator beg, InputIterator end)
	:v(beg,end){}
	T & operator[](int index)
	{ // kompakt
			return v[ (index<0?v.size():0) + index ];
	}
	T const& operator[](int index)const
	{ // elaboriert
	 	if (index <0)
			return v[v.size()+index];
		else
			return v[index];
	}
	T & at(int index) {
		return v.at((index<0?v.size():0)+index);
	}
	T const & at(int index) const {
		return v.at((index<0?v.size():0)+index);
	}
	void push_back(T const& t){ v.push_back(t); }
	iterator begin(){ return v.begin();}
	const_iterator begin() const { return v.begin();}
	iterator end() { return v.end();}
	const_iterator end() const { return v.end();}
	size_type size() const { return v.size(); }
};
#endif /*VECTOR_H_*/
