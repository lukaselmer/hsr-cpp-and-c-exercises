#include "Person.h"
#include <iostream>
#include <boost/bind.hpp>
#include <boost/ref.hpp>
#include <algorithm>
struct PersonImpl
{
	std::string name;
	PersonPtr vater;
	PersonPtr mutter;
	std::vector<PersonPtr> kinder;
	PersonImpl(std::string nam,PersonPtr vati, PersonPtr mutti)
	:name(nam),vater(vati),mutter(mutti){
		std::cout << name << " wird geboren\n";
	}
	~PersonImpl(){
		std::cout << name << " stirbt.\n";
	}
	std::string getName() const {
		return name;
	}
	void setKind(PersonPtr kind){
			kinder.push_back(kind);
	}
	void loescheElternTeil(PersonPtr elternTeil){
		if(vater==elternTeil) vater=PersonPtr();
		if(mutter==elternTeil) mutter=PersonPtr();
	}
	void loescheKind(PersonPtr kind){
		std::vector<PersonPtr>::iterator found =
			std::find(kinder.begin(),kinder.end(),kind);
		if (found != kinder.end()) kinder.erase(found);
	}
	void loescheKinder(PersonPtr elternTeil){
		for_each(kinder.begin(),kinder.end(),
			boost::bind(&Person::loescheElternTeil,_1,elternTeil));
		kinder.clear();
	}
	void print(std::ostream &os) const{
		os << name << ", ";
	}
	void printEltern(std::ostream&os) const{
		if (vater) {
			os << " vater: " ;
			vater->print(os);
		}
		if (mutter) {
			os << " mutter: ";
			(*mutter).print(os);
		}
		os << std::endl;
	}
	void printKinder(std::ostream&os) const {
		for_each(kinder.begin(),kinder.end(),
			boost::bind(&Person::print,_1,boost::ref(os)));
	}
};
Person::Person(std::string nam,PersonPtr vati,PersonPtr mutti)
:pImpl(new PersonImpl(nam,vati,mutti))
{
	 if (vati) vati->setKind(this);
	 if (mutti) mutti->setKind(this);
}
Person::~Person() {
	if (pImpl->vater)
		pImpl->vater->loescheKind(this);
	if (pImpl->mutter)
		pImpl->mutter->loescheKind(this);
}
std::string Person::getName() const {
	return pImpl->getName();
}
void Person::setKind(PersonPtr kind){
	pImpl->setKind(kind);
}
void Person::print(std::ostream &os) const {
	pImpl->print(os);
}
void Person::printEltern(std::ostream&os) const {
	pImpl->printEltern(os);
}
void Person::loescheElternTeil(PersonPtr elternteil)
{
	pImpl->loescheElternTeil(elternteil);
}

void Person::loescheKind(PersonPtr kind)
{
	pImpl->loescheKind(kind);
}

void Person::printKinder(std::ostream&os) const {
	pImpl->printKinder(os);
}
void Person::loescheKinder(){
	pImpl->loescheKinder(this);
}
std::ostream& operator<<(std::ostream &out, Person const &p){
	p.print(out); p.printEltern(out);
	out << "\tKinder: ";
	p.printKinder(out);
	out << std::endl;
	return out;
}

