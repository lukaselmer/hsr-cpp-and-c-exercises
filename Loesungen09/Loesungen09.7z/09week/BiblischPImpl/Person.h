#ifndef PERSON_H_
#define PERSON_H_
#include <iostream>
#include <vector>
#include <string>
#include <iosfwd>
#include <boost/shared_ptr.hpp>
typedef class Person * PersonPtr;
class Person
{
	boost::shared_ptr<class PersonImpl> pImpl;
public:
	Person(std::string nam,PersonPtr vati=PersonPtr(), PersonPtr mutti=PersonPtr());
	~Person();
	std::string getName() const ;
	void setKind(PersonPtr kind);
	void loescheKinder();
	void loescheKind(PersonPtr kind);
	void loescheElternTeil(PersonPtr elternteil);
	void print(std::ostream &os) const;
	void printEltern(std::ostream&os)const;
	void printKinder(std::ostream&os)const;
private:
	Person(Person const &);
	Person& operator=(Person const&);
};
std::ostream& operator<<(std::ostream& os,Person const &p);

#endif /*PERSON_H_*/
