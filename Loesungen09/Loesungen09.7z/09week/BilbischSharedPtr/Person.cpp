#include "Person.h"
#include <iostream>
#include <boost/bind.hpp>
#include <boost/ref.hpp>
#include <algorithm>

Person::Person(std::string nam,PersonPtr vati,PersonPtr mutti)
:name(nam),vater(vati),mutter(mutti)
{
	std::cout << name << " wird geboren\n";
}
void Person::setKind(PersonPtr kind){
	kinder.push_back(kind);
}
void Person::print(std::ostream &os) const {
	os << name << ", ";
}
void Person::printEltern(std::ostream&os) const {
	if (vater) {
		os << " vater: " ;
		vater->print(os);
	}
	if (mutter) {
		os << " mutter: ";
		(*mutter).print(os);
	}
	os << std::endl;
}
PersonPtr Person::make(std::string nam, PersonPtr vati, PersonPtr mutti)
{
	 PersonPtr baby(new Person(nam,vati,mutti));
	 if (vati) vati->setKind(baby);
	 if (mutti) mutti->setKind(baby);
	 return baby;
}

void Person::kill(PersonPtr &victim)
{
	if (!victim) return;
	if (victim->vater) {
		victim->vater->loescheKind(victim);
	}
	if (victim->mutter) {
		victim->mutter->loescheKind(victim);
	}
	victim->loescheElternTeilBeiKindern(victim);
	victim.reset(); // reduce refcount....
}

std::string Person::getName() const
{
	return name;
}

void Person::printKinder(std::ostream&os) const {
	for_each(kinder.begin(),kinder.end(),
		boost::bind(&Person::print,_1,boost::ref(os)));
}
Person::~Person(){
	std::cout << name << " stirbt.\n";
}
void Person::loescheKinder(){
	kinder.clear();
}

std::ostream& operator<<(std::ostream &out, PersonPtr const &p){
	if (p){
	p->print(out); p->printEltern(out);
	out << "\tKinder: ";
	p->printKinder(out);
	out << std::endl;
	} else {
		out << "no person"<<std::endl;
	}
	return out;
}

void Person::loescheKind(PersonPtr totesKind)
{
	std::vector<PersonPtr>::iterator found = find(kinder.begin(),kinder.end(),totesKind);
	if (found != kinder.end())
		kinder.erase(found);
}

void Person::loescheElternTeilBeiKindern(PersonPtr toterElternteil)
{
	for_each(kinder.begin(),kinder.end(),
			boost::bind(&Person::loescheElternTeilBeiKind,_1,toterElternteil));

}

void Person::loescheElternTeilBeiKind(PersonPtr toterElternteil)
{
	if (vater == toterElternteil) {
		vater.reset();
	}
	if (mutter == toterElternteil) {
		mutter.reset();
	}
}






