#include "Haustier.h"
#include <iostream>

Haustier::Haustier(std::string name, std::string klasse)
:name(name),klassenname(klasse)
{
}

void Haustier::gibLaut() const
{
	std::cout << "undefined..." << std::endl;
}

void Haustier::printName() const
{
	std::cout << "ich heisse " << name << " und bin ein " << klassenname << std::endl;
}

Haustier::~Haustier()
{
	std::cout << name << " geht ein." << std::endl;
}

void Haustier::printEigenschaft() const
{
	std::cout << "kenn ich nicht " << std::endl;
}








