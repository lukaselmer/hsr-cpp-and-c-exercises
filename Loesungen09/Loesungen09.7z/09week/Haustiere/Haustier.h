#ifndef HAUSTIER_H_
#define HAUSTIER_H_
#include <string>
class Haustier {
protected:
	const std::string name;
	const std::string klassenname;
public:
	Haustier(std::string name,std::string klasse);
	virtual ~Haustier();
	virtual void gibLaut() const;
	void printName() const;
	virtual void printEigenschaft() const;
};

#endif /* HAUSTIER_H_ */
