#include "Katze.h"
#include <iostream>

Katze::Katze(std::string name, std::string schmusefaktor)
:Haustier(name,"Katze"),schmusefaktor(schmusefaktor){
}


void Katze::gibLaut() const
{
	std::cout << "Miau miau" <<std::endl;
}

void Katze::printEigenschaft() const
{
	std::cout << name << ": " << schmusefaktor << std::endl;
}


