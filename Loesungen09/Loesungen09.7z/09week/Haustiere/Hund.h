#ifndef HUND_H_
#define HUND_H_

#include "Haustier.h"

class Hund: public Haustier {
	bool istKampfhund;
public:
	Hund(std::string name,bool istKampfhund);
	virtual void gibLaut() const;
	virtual void printEigenschaft() const;

};

#endif /* HUND_H_ */
