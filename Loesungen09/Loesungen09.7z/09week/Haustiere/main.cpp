#include "Haustier.h"
#include "Hund.h"
#include "Katze.h"
#include <vector>
#include <functional>
#include <iostream>
void HaustierDeleter(Haustier *&t){
	delete t;
	t=0;
}
int main(){
	std::vector<Haustier*> alleTiere;
	alleTiere.push_back(new Hund("Lassie",false));
	alleTiere.push_back(new Hund("Fass!",true));
	alleTiere.push_back(new Katze("Mikesch","schmust gerne"));
	alleTiere.push_back(new Katze("PussInBoots","fechtet gerne"));
	alleTiere.push_back(new Katze("Streuner","kratzt"));
	std::cout << "Es gibt Futter\n";
	for_each(alleTiere.begin(),alleTiere.end(),std::mem_fun(&Haustier::gibLaut));
	std::cout << "Alle meine Tiere\n";
	for_each(alleTiere.begin(),alleTiere.end(),std::mem_fun(&Haustier::printName));
	std::cout << "Ihre Eigenschaften:\n";
	for_each(alleTiere.begin(),alleTiere.end(),std::mem_fun(&Haustier::printEigenschaft));
	for_each(alleTiere.begin(),alleTiere.end(),HaustierDeleter);
	alleTiere.clear();
}
