#ifndef SAFEINTVECTOR_H_
#define SAFEINTVECTOR_H_

#include <vector>
class SafeIntVector: public std::vector<int> {
public:
	typedef std::vector<int> base;
	typedef  base::size_type size_type;
	typedef  base::difference_type difference_type;
	typedef  base::reference reference;
	typedef  base::const_reference const_reference;
	SafeIntVector(){}
	SafeIntVector(size_type n):std::vector<int>(n){}
	reference operator[](size_type i){
		return at(i);
	}
	const_reference operator[](size_type i) const {
		return at(i);
	}
};

#endif /* SAFEINTVECTOR_H_ */
