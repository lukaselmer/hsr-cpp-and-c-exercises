#ifndef LINKEDLIST_H_
#define LINKEDLIST_H_

class LinkedList {
	struct Node {
		int  value;
		Node *next;
		Node(int,Node *);
		~Node();
	};
	Node *first;
	Node *last;
public:
	LinkedList();
	~LinkedList();
	LinkedList(LinkedList const&);
	bool empty() const;
	void push_front(int);
	void pop_front();
	void push_back(int);
	void pop_back();
	int back() const;
	int front() const;
	bool contains(int) const;
	void insertBefore(int key, int value);
	void insertAfter(int key,int value);
};

#endif /* LINKEDLIST_H_ */
