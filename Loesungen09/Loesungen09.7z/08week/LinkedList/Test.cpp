#include "cute.h"
#include "ide_listener.h"
#include "cute_runner.h"
#include "LinkedList.h"
#include <stdexcept>
void testEmptyList() {
	LinkedList l;
	ASSERT(l.empty());
}
void testInsertOneElement(){
	LinkedList l;
	l.push_front(7);
	ASSERT(not l.empty());
	ASSERT_EQUAL(7,l.front());
}
void testInsertMultipleElements(){
	LinkedList l;
	l.push_front(7);
	l.push_front(8);
	l.push_front(9);
	ASSERT(not l.empty());
	ASSERT_EQUAL(9,l.front());
	l.pop_front();
	ASSERT_EQUAL(8,l.front());
	l.pop_front();
	ASSERT_EQUAL(7,l.front());
	l.pop_front();
	ASSERT(l.empty());
	ASSERT_THROWS(l.front(),std::out_of_range);
	ASSERT_THROWS(l.pop_front(),std::logic_error);
}

void testAppendOneElement(){
	LinkedList l;
	l.push_back(1);
	ASSERT(not l.empty());
	ASSERT_EQUAL(1,l.front());
	ASSERT_EQUAL(1,l.back());
	ASSERT(l.contains(1));
	ASSERT(not l.contains(0));
}
LinkedList generateLinkedList()
{
    LinkedList l;
    l.push_back(2);
    l.push_front(3);
    l.push_back(1);
    l.push_front(4);
    return l; // 4321
}

void testAppendInsertAndRemove(){
	LinkedList l = generateLinkedList();
	ASSERT_EQUAL(4,l.front());
	ASSERT_EQUAL(1,l.back());
	l.pop_back();
	ASSERT_EQUAL(2,l.back());
	l.pop_back();
	ASSERT_EQUAL(3,l.back());
	l.pop_front();
	ASSERT_EQUAL(3,l.front());
	l.pop_back();
	ASSERT(l.empty());
	ASSERT_THROWS(l.back(),std::out_of_range);
	ASSERT_THROWS(l.pop_back(),std::logic_error);
}
void testContains(){
	LinkedList l = generateLinkedList();
	ASSERT(l.contains(2));
	ASSERT(l.contains(3));
	ASSERT(l.contains(4));
	ASSERT(l.contains(1));
	ASSERT(not l.contains(0));
}
void testInsertBeforeValue(){
	LinkedList l = generateLinkedList(); // 4321
	l.insertBefore(4,42);//42,4,3,2,1
	l.insertAfter(1,43);//42,4,3,2,1,43
	l.insertBefore(4,41);//42,41,4,3,2,1,43
	l.insertAfter(4,40);//42,41,4,40,3,2,1,43
	l.insertBefore(43,0);//42,41,4,40,3,2,1,0,43

	ASSERT_EQUAL(42,l.front()); l.pop_front();
	ASSERT_EQUAL(41,l.front()); l.pop_front();
	ASSERT_EQUAL(4,l.front()); l.pop_front();
	ASSERT_EQUAL(40,l.front()); l.pop_front();
	ASSERT_EQUAL(3,l.front()); l.pop_front();
	ASSERT_EQUAL(2,l.front()); l.pop_front();
	ASSERT_EQUAL(1,l.front()); l.pop_front();
	ASSERT_EQUAL(0,l.front()); l.pop_front();
	ASSERT_EQUAL(43,l.front()); l.pop_front();
}



void runSuite(){
	cute::suite s;
	//TODO add your test here
	s.push_back(CUTE(testEmptyList));
	s.push_back(CUTE(testInsertOneElement));
	s.push_back(CUTE(testInsertMultipleElements));
	s.push_back(CUTE(testAppendOneElement));
	s.push_back(CUTE(testAppendInsertAndRemove));
	s.push_back(CUTE(testContains));
	s.push_back(CUTE(testInsertBeforeValue));
	cute::ide_listener lis;
	cute::makeRunner(lis)(s, "The Suite");
}

int main(){
    runSuite();
}



