#include "Person.h"
#include <iostream>
#include <boost/bind.hpp>
#include <boost/ref.hpp>
#include <algorithm>

Person::Person(std::string nam,Person *vati,Person *mutti)
:name(nam),vater(vati),mutter(mutti)
{
	if (vater) vater->setKind(this);
	if (mutter) mutter->setKind(this);
}
void Person::setKind(Person *kind){
	kinder.push_back(kind);
}
void Person::print(std::ostream &os)const{
	os << name << ", ";
}
void Person::printEltern(std::ostream&os)const{
	print(os);
	if (vater) {
		os << " vater: " ;
		vater->print(os);
	}
	if (mutter) {
		os << " mutter: ";
		(*mutter).print(os);
	}
	os << std::endl;
}
void Person::printKinder(std::ostream&os)const{
	for_each(kinder.begin(),kinder.end(),
		boost::bind(&Person::print,_1,boost::ref(os)));
}
Person::~Person(){
	if (vater) vater->removeKind(this);
	if (mutter) mutter->removeKind(this);
}
void Person::removeKind(Person *kind){
	kinder.erase(remove(kinder.begin(),kinder.end(),kind));
}

std::ostream & operator <<(std::ostream & os, const Person & p)
{
	p.printEltern(os);
	p.printKinder(os);
	return os;
}



