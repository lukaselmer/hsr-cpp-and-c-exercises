#include <string>
#include <iostream>
std::string readall(std::istream &in) {
	using namespace std;
    string line;
    string all;
    while (getline(in,line)){
         all += line;
    }
    return all;
}


int main(){
	readall(std::cin);
}
