#include "Ansi.h"
#include <boost/lexical_cast.hpp>

std::string Ansi::ESCAPE = "\033[";

std::string Ansi::Clear() { 
	return ESCAPE + "2J"; 
}
std::string Ansi::Bold() { 
	return ESCAPE + "1m"; 
}
std::string Ansi::Pos(int l, int c) { 
	return ESCAPE + boost::lexical_cast<std::string>(l) + ";" + boost::lexical_cast<std::string>(c) + "H"; 
}
std::string Ansi::Home() { 
	return Pos(0,0); 
}
std::string Ansi::ForeColor(Color c) { 
	return ESCAPE + boost::lexical_cast<std::string>( c + 30) + "m"; 
}
std::string Ansi::BackColor(Color c) { 
	return ESCAPE + boost::lexical_cast<std::string>(c + 40 ) + "m"; 
}
std::string Ansi::AttrOff() { 
	return ESCAPE + "0m"; 
}
std::string Ansi::Up(int n) { 
	return ESCAPE + boost::lexical_cast<std::string>(n) + "A"; 
}
std::string Ansi::Down(int n) { 
	return ESCAPE + boost::lexical_cast<std::string>(n) + "B"; 
}
std::string Ansi::Left(int n) { 
	return ESCAPE + boost::lexical_cast<std::string>(n) + "D"; 
}
std::string Ansi::Right(int n) { 
	return ESCAPE + boost::lexical_cast<std::string>(n) + "C"; 
}
