#ifndef ANSI_H_
#define ANSI_H_
#include <string>
struct Ansi {
    enum Color /* hier fehlt etwas */
        {black=0, red, green, yello, blue, magenta, cyan, white};
    
	static std::string ESCAPE; // = "\033[";
	static std::string Clear();
	static std::string ForeColor(Color c);
	static std::string BackColor(Color c);
	static std::string Bold();
	static std::string AttrOff();
	static std::string Pos(int l, int c);
	static std::string Home();
	static std::string Up(int n);
	static std::string Down(int n);
	static std::string Right(int n);
	static std::string Left(int n);
private:
	Ansi();
};
#endif /*ANSI_H_*/
