#include "SiebenSegmentZeile.h"
#include <iostream>
#include <numeric>
void SiebenSegmentZeile::fillLeft()
{
    while(theDigits.size() < 10)
        theDigits.insert(theDigits.begin(), SiebenSegmentZiffer(' '));

}
SiebenSegmentZeile::SiebenSegmentZeile(int zahl)
{
	do {
		int ziffer = zahl %10;
		zahl = zahl /10;
		theDigits.insert(theDigits.begin(),SiebenSegmentZiffer(ziffer));
	} while (zahl != 0);
    fillLeft();
}

void SiebenSegmentZeile::print(std::ostream &out,unsigned int factor)const {
	for (int i =0; i < SiebenSegmentZiffer::nOfLines; ++i){
		out << getLine(i,factor) << std::endl;
	}
}

SiebenSegmentZeile::SiebenSegmentZeile(std::string s)
{
	for (size_t i=0; i < s.size(); ++i)
		theDigits.push_back(SiebenSegmentZiffer(s[i]));
	fillLeft();
}

bool SiebenSegmentZeile::lineNeedsRepetition(int line) const
{
    return (line % 2);// only "odd" lines get repeated
}

std::string SiebenSegmentZeile::getLine(int line, unsigned int factor) const {
	std::string result;
	for(unsigned int count = factor; count > 0 ; --count){
		for (std::vector<SiebenSegmentZiffer>::const_iterator it =
				theDigits.begin(); it != theDigits.end(); ++it) {
			result += it->getDigitLine(line, factor);
		}
		if (lineNeedsRepetition(line) && count >1)
			result += "\n";
		else
			break;
	}
	return result;
}
