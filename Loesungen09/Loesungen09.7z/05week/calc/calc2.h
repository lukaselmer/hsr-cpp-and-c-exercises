#ifndef CALC2_H_
#define CALC2_H_
#include <iosfwd>
int calc(int,int,char);
int calc(std::istream &in);
#endif /* CALC2_H_ */
