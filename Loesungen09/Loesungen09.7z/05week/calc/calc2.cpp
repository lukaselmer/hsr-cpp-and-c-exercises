#include "calc2.h"
#include <iostream>
#include <stdexcept>
int calc(std::istream & in)
{
	int x,y;
	char oper;
	in >> x >> oper >> y;
	if (!in) throw std::logic_error("invalid input");
	return calc(x,y,oper);
}

int calc(int x, int y, char oper)
{
	switch(oper){
	case '+': return x+y;
	case '-': return x-y;
	case '*': return x*y;
	case '/': return y!=0?x/y:throw std::logic_error("division by 0"); // avoid crashes
	}
	throw std::logic_error("invalid operator");
}



