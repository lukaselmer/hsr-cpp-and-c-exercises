#include "Bird.h"
#include <iostream>

unsigned int Bird::nOfBirds = 0;

Bird::Bird()
:counter(Bird::nOfBirds++){
	std::cout << "Bird born : " << counter << std::endl;
}

Bird::Bird(const Bird & bird)
:counter(Bird::nOfBirds++)
{
	std::cout << "Bird copy born : " << counter << " from Bird " << bird.counter <<std::endl;

}

Bird::~Bird() {
	std::cout << "Bird died : " << counter << std::endl;
}
