#ifndef BIRD_H_
#define BIRD_H_

class Bird {
	unsigned int counter;
	static unsigned int nOfBirds;
public:
	Bird();
	Bird(Bird const &);
	~Bird();
};

#endif /* BIRD_H_ */
