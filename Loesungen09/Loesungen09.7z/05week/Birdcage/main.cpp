#include "Bird.h"
#include <iostream>
#include <vector>

void throwsBird() {
	std::cout << "throwing a bird" << std::endl;
	throw Bird();
}

int main() {
	{
	std::vector<Bird> birdcage;

	birdcage.push_back(Bird());
	birdcage.push_back(Bird());

	}
	try {
		throwsBird();
	}catch (Bird &b){ // what happens if caught by value?

	}
	std::cout << "end of main" << std::endl;
}
