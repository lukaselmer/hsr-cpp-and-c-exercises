#include "cute.h"
#include "ide_listener.h"
#include "cute_runner.h"
#include "InputReader.h"
#include "FormattedOutput.h"
#include <iostream>
#include <sstream>
#include <boost/assign.hpp>

void ParseLineTest() {
	using namespace std;
	InputReader::mapPairType aPair;
	ASSERT(InputReader::ParseLine(string("abc def 3.45"), aPair));
	ASSERT_EQUAL(string("abc def"), aPair.first);
	ASSERT_EQUAL_DELTA(3.45, aPair.second, 0.001);
	ASSERT(InputReader::ParseLine(string("qrs 3.45"), aPair));
	ASSERT_EQUAL(string("qrs"), aPair.first);
	ASSERT_EQUAL_DELTA(3.45, aPair.second, 0.001);
	ASSERT(!InputReader::ParseLine(string("def3.45"), aPair));
	ASSERT(!InputReader::ParseLine(string("def"), aPair));
	ASSERT(!InputReader::ParseLine(string("3.45"), aPair));
}

void ProcessInputTest() {
	using namespace std;
	InputReader::mapType aMap;
	istringstream aStream("abc def 3.45\n\nqrs 7.77");
	InputReader::ProcessInput(aStream, aMap);
	ASSERT_EQUAL(size_t(2), aMap.size());
}

void PrintLineTest() {
	using namespace std;
	using namespace boost::assign;
	InputReader::mapType aMap;
	insert( aMap )("bev (1)", 2.45)("thebev2", 3.75);
	{
		ostringstream oS;
		printBeverages thePrinter(oS, aMap, '_', 10);
		thePrinter(0);
		ASSERT_EQUAL("______bev (1)___thebev2\n", oS.str());
	}
	{
		ostringstream oS;
		printBeverages thePrinter(oS, aMap, '_', 10);
		thePrinter(1);
		ASSERT_EQUAL("__1______2.45______3.75\n", oS.str());
	}
	{
		ostringstream oS;
		printBeverages thePrinter(oS, aMap, '_', 10);
		thePrinter(2);
		ASSERT_EQUAL("__2______4.90______7.50\n", oS.str());
	}
	{
		ostringstream oS;
		printBeverages thePrinter(oS, aMap, '*', 9);
		thePrinter(2);
		ASSERT_EQUAL("**2*****4.90*****7.50\n", oS.str());
	}
}

void PrintMapTest() {
	using namespace std;
	using namespace boost::assign;
	InputReader::mapType aMap;
	insert( aMap )("bev (1)", 2.45)("thebev2", 3.75);
	{
		ostringstream oS, osExp;
		vector<int> v;
		v += 0,1,2,3,4;
		for_each(v.begin(), v.end(), printBeverages(oS, aMap, '_', 10));
		osExp << "______bev (1)___thebev2" << endl;
		osExp << "__1______2.45______3.75" << endl;
		osExp << "__2______4.90______7.50" << endl;
		osExp << "__3______7.35_____11.25" << endl;
		osExp << "__4______9.80_____15.00" << endl;
		ASSERT_EQUAL(osExp.str(), oS.str());
	}
}

void runSuite() {
	cute::suite s;
	//TODO add your test here
	s.push_back(CUTE(ParseLineTest));
	s.push_back(CUTE(ProcessInputTest));
	s.push_back(CUTE(PrintLineTest));
	s.push_back(CUTE(PrintMapTest));
	cute::ide_listener lis;
	cute::makeRunner(lis)(s, "The Suite");
}

int main() {
	runSuite();
}
