#include <iostream>
#include <string>
#include <bitset>

struct Bin {
	Bin(unsigned int val):bits(val){}
	std::string toBin() const { return bits.to_string();}
private:
	std::bitset<8*sizeof(unsigned int)> bits;
};

int main() {
	Bin theBinaryString(1234);
	std::cout << theBinaryString.toBin() << std::endl;
	return 0;
}
