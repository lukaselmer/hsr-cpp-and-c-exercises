/*
 * main.cpp
 *
 *  Created on: May 6, 2009
 *      Author: m1huber
 */

#include "InputReader.h"
#include "FormattedOutput.h"
#include <iostream>
#include <fstream>
#include <boost/program_options.hpp>
#include <boost/shared_ptr.hpp>

using namespace std;

struct natural {
	int nCount;
	natural(int nEl = 0) :
		nCount(nEl) {
	}
	int operator()() {
		return nCount++;
	}
};

typedef boost::shared_ptr<ifstream> tiSP;
typedef boost::shared_ptr<ofstream> toSP;

template<class SPType>
SPType OpenStream(const string strFileName) {
	typedef typename SPType::element_type StreamType;
	SPType fP(new StreamType(strFileName.c_str()));
	if (fP->good()) {
		cout << "file to use is [" << strFileName << "]" << endl;
	} else {
		cout << "file not accessible [" << strFileName << "], using console" << endl;
		fP.reset();
	}
	return fP;
}

namespace po = boost::program_options;

int main(int ac, char* av[]) {

	int iMult = { 0 }, iWidth(20);
	char cFill = '_';
	string strFileName, strOutFile;

	po::options_description desc("Allowed options");
	desc.add_options()
		("help,h", "produce help message")
		("filler,f", po::value<char>(&cFill)->default_value('_'), "fill character to use")
		("colwidth,w", po::value<int>(&iWidth)->default_value(20),"column width of beverages")
		("lines,n", po::value<int>(&iMult)->default_value(10),"number of price lines to print")
		("input-file,i",po::value<string>(&strFileName), "input file")
		("output-file,o",po::value<string>(&strOutFile), "output file");
	po::variables_map vm;
	po::store(po::parse_command_line(ac, av, desc), vm);
	po::notify(vm);

	if (vm.count("help")) {
		cout << desc << endl;
		return 1;
	}

	tiSP ifp;
	toSP ofp;
	if (vm.count("input-file")) {
		ifp = OpenStream<tiSP>(strFileName);
	}
	if (vm.count("output-file")) {
		ofp = OpenStream<toSP>(strOutFile);
	}

	istream& iS(ifp ? *ifp : cin);
	ostream& oS(ofp ? *ofp : cout);

	InputReader::mapType beveragesMap;
	InputReader::ProcessInput(iS, beveragesMap);
	vector<int> nLines(iMult + 1);

	generate(nLines.begin(), nLines.end(), natural(0));
	for_each(nLines.begin(), nLines.end(), printBeverages(oS, beveragesMap, cFill, iWidth));
	return 0;
}
