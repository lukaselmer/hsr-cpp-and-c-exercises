#include <vector>
#include <algorithm>
#include <cstdlib>
#include <iterator>
#include <iostream>
#include <exception>
#include <string>
#include <cstring>

struct RandomError : std::exception {
//	RandomError(char const *m):message(m) {} // only works with literals!
	RandomError(char const *m) { strncpy(message,m,sizeof(message)-1);} // only works with literals!
	char const *what() const  throw(){ return message; }
private:
	//std::string message; // this is a problem might throw on allocation!
//	char const * const message; // only useful with literals
	char message[100]; // exception allocated on the stack

};


struct counter{
	int operator()(){
		if (rand()%1000 < 2) throw RandomError("buh");
		return count++;
	}
	int count;
	counter(int start=0):count(start){}
};

int main() {

	srand(time(0));

	std::vector<int> v;
	try {
	generate_n(std::back_inserter(v),1000,counter());
	} catch (std::exception &e){
		std::cout << "caught " << e.what() << std::endl;
	}
	std::cout << "vector hat l�nge: " << v.size();
}
