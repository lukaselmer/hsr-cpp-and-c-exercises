/*
 * InputReader.h
 *
 *  Created on: May 6, 2009
 *      Author: m1huber
 */

#ifndef INPUTREADER_H_
#define INPUTREADER_H_

#include <iosfwd>
#include <string>
#include <map>

#include <boost/utility.hpp>

class InputReader : boost::noncopyable {
	InputReader();
public:
	typedef std::string descType;
	typedef double numberType;
	typedef std::map<descType, numberType> mapType;
	typedef std::pair<descType, numberType> mapPairType;
	typedef std::istream streamType;
	static void ProcessInput(streamType &theStream, mapType &getraenkeMap);
	static bool ParseLine(std::string const &strLine, mapPairType &thePair);
};

#endif /* INPUTREADER_H_ */
