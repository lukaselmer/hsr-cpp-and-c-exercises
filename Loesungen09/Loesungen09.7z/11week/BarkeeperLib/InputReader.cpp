/*
 * InputReader.cpp
 *
 *  Created on: May 6, 2009
 *      Author: m1huber
 */

#include "InputReader.h"
#include <iostream>
#include <iomanip>
#include <iterator>
#include <sstream>

void InputReader::ProcessInput(streamType &theStream, mapType &getraenkeMap) {
	using namespace std;
	mapPairType aPair;
	string strLine;
	while (getline(theStream, strLine, '\n')) {
		if (strLine.length() && ParseLine(strLine, aPair)) {
			getraenkeMap.insert(aPair);
		}
	}
}

bool InputReader::ParseLine(std::string const& strLine, mapPairType & thePair) {
	using namespace std;
	descType strGName;
	numberType dPrice;
	bool bSuccess(false);
	size_t iLastOcc(string::npos);
	if ((iLastOcc = strLine.rfind(' ', iLastOcc)) != string::npos) {
		strGName = strLine.substr(0, iLastOcc);
		istringstream aStream(strLine.substr(iLastOcc + 1));
		aStream >> dPrice;
		if (!aStream.fail()) {
			bSuccess = true;
			thePair = mapPairType(strGName, dPrice);
		}
	}
	if (!bSuccess) {
		cerr << "failed converting line [" << strLine << "]" << endl
				<< "\tformat should be: \"The Name of my beverage 3.56\""
				<< endl;
	}
	return bSuccess;
}

