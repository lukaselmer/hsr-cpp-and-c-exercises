#include "SiebenSegmentZiffer.h"
#include <boost/assign.hpp>

using namespace boost::assign;

SiebenSegmentZiffer::SiebenSegmentZiffer(int digit)
{
	using namespace boost::assign;
	switch(digit){
	case 0: digitLines += " - ","| |","   ","| |"," - "; break;
	case 1:	digitLines += "   ","  |","   ","  |","   "; break;
	case 2:	digitLines += " - ","  |"," - ","|  "," - "; break;
	case 3:	digitLines += " - ","  |"," - ","  |"," - "; break;
	case 4:	digitLines += "   ","| |"," - ","  |","   "; break;
	case 5:	digitLines += " - ","|  "," - ","  |"," - "; break;
	case 6: digitLines += " - ","|  "," - ","| |"," - "; break;
	case 7: digitLines += " - ","  |","   ","  |","   "; break;
	case 8: digitLines += " - ","| |"," - ","| |"," - "; break;
	case 9: digitLines += " - ","| |"," - ","  |"," - "; break;
	default: throw invalid_digit();
	}
}

std::string SiebenSegmentZiffer::getDigitLine( int line) const {
	return digitLines.at(line);
}
