#include "SiebenSegmentZeile.h"
#include <iostream>
#include <numeric>
SiebenSegmentZeile::SiebenSegmentZeile(int zahl)
{
	do {
		int ziffer = zahl %10;
		zahl = zahl /10;
		theDigits.insert(theDigits.begin(),SiebenSegmentZiffer(ziffer));
	} while (zahl != 0);
}

void SiebenSegmentZeile::print(std::ostream &out)const {
	for (int i =0; i < SiebenSegmentZiffer::nOfLines; ++i){
		out << getLine(i) << std::endl;
	}
}

std::string SiebenSegmentZeile::getLine(int line) const {
	std::string result;
	for (std::vector<SiebenSegmentZiffer>::const_iterator it= theDigits.begin();
	    it != theDigits.end(); ++it){
		result += it->getDigitLine(line);
	}
	return result;
}
