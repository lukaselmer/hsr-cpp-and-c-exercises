#ifndef SiebenSegmentZeile_H_
#define SiebenSegmentZeile_H_
#include <vector>
#include <iosfwd>
#include "SiebenSegmentZiffer.h"
class SiebenSegmentZeile {
public:
	SiebenSegmentZeile(int zahl);
	void print(std::ostream &out,unsigned int factor=1) const;
private:
	std::string getLine(int line, unsigned int factor=1)const;
    bool lineNeedsRepetition(int line) const;
	std::vector<SiebenSegmentZiffer> theDigits;
};
#endif /*SiebenSegmentZeile_H_*/
