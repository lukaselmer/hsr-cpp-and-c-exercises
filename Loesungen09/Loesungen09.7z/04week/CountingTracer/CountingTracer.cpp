#include <iostream>
#include <string>

using namespace std;
class CountingTracer {
	std::string name;
	int nOfObject;
public:
	static int created;
	static int destroyed;
	CountingTracer(string name):name(name),nOfObject(CountingTracer::created){
		++created;
		std::cout << "ctor " << name << std::endl;
	}
	~CountingTracer() {
		++destroyed;
		std::cout << "dtor " << name << std::endl;
	}
};
int CountingTracer::created;
int CountingTracer::destroyed;

void do_main() {
    CountingTracer t1("erster");
    {
        CountingTracer t2("zweiter");
        CountingTracer t3("dritter");
    }
    CountingTracer t4("vierter");
}
int main(){
	do_main();
	std::cout << "created: " << CountingTracer::created << std::endl;
	std::cout << "destroyed: " << CountingTracer::destroyed << std::endl;
}
