#include "cute.h"
#include "ide_listener.h"
#include "cute_runner.h"
#include "SiebenSegmentZeile.h"
void testZero() {
	SiebenSegmentZeile null(0);
	std::stringstream out;
	null.print(out);
	ASSERT_EQUAL(" - \n| |\n   \n| |\n - \n",out.str());
}
void testOne() {
	SiebenSegmentZeile one(1);
	std::stringstream out;
	one.print(out);
	ASSERT_EQUAL("   \n  |\n   \n  |\n   \n",out.str());
}
void testLarge78(){
	SiebenSegmentZeile seventyeight(78);
	std::stringstream out;
	seventyeight.print(out,2);
	ASSERT_EQUAL(
	" --  -- \n"
	"   ||  |\n"
	"   ||  |\n"
	"     -- \n"
	"   ||  |\n"
	"   ||  |\n"
	"     -- \n",out.str());

}


void test1234567890() {
	SiebenSegmentZeile alldigits(1234567890);
	std::stringstream out;
	alldigits.print(out);
	ASSERT_EQUAL("    -  -     -  -  -  -  -  - \n"
			"  |  |  || ||  |    || || || |\n"
			"    -  -  -  -  -     -  -    \n"
			"  ||    |  |  || |  || |  || |\n"
			"    -  -     -  -     -  -  - \n", out.str());
}

void runSuite() {
	cute::suite s;
	//TODO add your test here
	s.push_back(CUTE(testZero));
	s.push_back(CUTE(testOne));
	s.push_back(CUTE(test1234567890));
	s.push_back(CUTE(testLarge78));
	cute::ide_listener lis;
	cute::makeRunner(lis)(s, "The Suite");
}

int main() {
	runSuite();
}

