#include <iostream>
#include <iterator>
#include <vector>
#include <algorithm>
#include <functional>
#include <boost/bind.hpp>

int main(){
	using namespace std;
	istream_iterator<int> eof;
	vector<int> v(istream_iterator<int>(cin),eof);
	v.erase(remove_if(v.begin(),v.end(),boost::bind(modulus<int>(),_1,3)),v.end());
	transform(v.begin(),v.end(),v.begin(),boost::bind(divides<int>(),_1,3));
	copy(v.begin(),v.end(),ostream_iterator<int>(cout,", "));
}
