#include <iostream>

struct CtorDtor {
	CtorDtor() { std::cout << "Initialiserung\n";}
	~CtorDtor(){ std::cout << "Aufraeumen\n";}
};

CtorDtor globaltrace;

int main() {
    std::cout << "Hello, world\n";
}
