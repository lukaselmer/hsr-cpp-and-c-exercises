Readme!
1) Unzip
2) Create folder for images (e.g. c:/panorama)
3) run download_panorama.exe
:-)
